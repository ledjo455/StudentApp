﻿Public Interface ICounter
    Function GetNumber()

End Interface
