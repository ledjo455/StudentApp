﻿Imports StudentApp

Public Class Student
    Inherits User
    Implements ICounter

    Public Sub New(idP As Integer, nameP As String, surnameP As String, ageP As Integer, majorP As String, minorP As String, passwordP As String)
        MyBase.New(idP, nameP, surnameP, passwordP)
        Me.AgeProperty = ageP
        Me.MajorProperty = majorP
        Me.MinorProperty = minorP

    End Sub


    Public Property AgeProperty As Integer

    Public Property MajorProperty As String
    Public Property MinorProperty As String

    Public Function GetNumber() As Object Implements ICounter.GetNumber
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select count(*) from student"
        Dim dt As DataTable = con.getData(query)
        Return dt.Rows.Item(0).Item(0)
    End Function

    Public Shared Function AddStudent(St As Student) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "insert into student (name, surname, age, major, minor, password) values ('" & St.NameProperty & "','" & St.SurnameProperty & "'," & St.AgeProperty & " ,'" & St.MajorProperty & "', '" & St.MinorProperty & "', '" & St.PasswordProperty & "')"
        If con.addOrDeleteData(query) Then 'course added succesfully
            Return True
        Else 'database error occured
            Return False
        End If
    End Function

    Public Shared Function DeleteStudent(id As Integer) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query2 As String = "delete from StudentCourse where studentid=" & id
        Dim query3 As String = "delete from comment where studentid=" & id
        Dim query4 As String = "delete from friendship where studentid=" & id

        Dim query As String = "delete from student where id=" & id
        If con.addOrDeleteData(query3) And con.addOrDeleteData(query4) And con.addOrDeleteData(query2) And con.addOrDeleteData(query) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function DeleteComment(sid As Integer) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "delete from Comment where StudentID=" & sid
        If con.addOrDeleteData(query) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Shared Function DeleteFriendship(sid As Integer) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "delete from Friendship where StudentID=" & sid
        If con.addOrDeleteData(query) Then
            Return True
        Else
            Return False
        End If
    End Function

End Class
