﻿Imports StudentApp

Public Class Course
    Implements ICounter
    Public Property ID As Integer
    Public Property Title As String
    Public Property Instructor As String
    Public Property Credits As Integer
    Public Property Day As String
    Public Property Time As String
    Public Property Location As String
    Public Property Faculty As String
    Public Property Department As String
    Public Property Eligibility As String

    Public Sub New(id As Integer, title As String, instr As String, cred As Integer, day As String, time As String, location As String, faculty As String, dep As String, elig As String)
        Me.ID = id
        Me.Title = title
        Me.Instructor = instr
        Me.Credits = cred
        Me.Day = day
        Me.Time = time
        Me.Location = location
        Me.Faculty = faculty
        Me.Department = dep
        Me.Eligibility = elig


    End Sub

    Public Function GetNumber() Implements ICounter.GetNumber
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select count(*) from course"
        Dim dt As DataTable = con.getData(query)
        Return dt.Rows.Item(0).Item(0)
    End Function

    Public Shared Function AddCourse(c As Course) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "insert into course (title, instructor, credits, day, time, class, faculty, department, eligibility) values ('" & c.Title & "','" & c.Instructor & "'," & c.Credits & " ,'" & c.Day & "', '" & c.Time & "', '" & c.Location & "', '" & c.Faculty & "', '" & c.Department & "', '" & c.Eligibility & "')"
        If con.addOrDeleteData(query) Then 'course added succesfully
            Return True
        Else 'database error occured
            Return False
        End If
    End Function

    Public Shared Function DeleteCourse(id As Integer) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "delete from course where id=" & id
        If con.addOrDeleteData(query) Then
            Return True
        Else
            Return False
        End If
    End Function
End Class
