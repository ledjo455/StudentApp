﻿Public Class User
    Private password As String
    Public Sub New(idP As Integer, nameP As String, surnameP As String, passP As String)
        IDPoperty = idP
        NameProperty = nameP
        SurnameProperty = surnameP
        PasswordProperty = passP
    End Sub

    Public ReadOnly Property IDPoperty As Integer

    Public Property NameProperty As String

    Public Property SurnameProperty As String

    Public Property PasswordProperty
        Get
            Return password
        End Get
        Set(value)
            password = value
        End Set
    End Property



End Class
