﻿Public Class Administrator
    Inherits User

    Private Property username As String

    Public Sub New(idP As Integer, nameP As String, surnameP As String, usernameP As String, passP As String)
        MyBase.New(idP, nameP, surnameP, passP)
        username = usernameP
    End Sub

End Class
