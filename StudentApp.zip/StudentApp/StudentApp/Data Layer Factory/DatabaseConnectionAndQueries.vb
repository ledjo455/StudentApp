﻿Imports System.Data.SqlClient
Public Class DatabaseConnectionAndQueries
    Dim con As SqlConnection

    Public Sub New()
        con = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\FUJITSU E754\Desktop\Backup\Vb\VBProject\StudentApp\StudentApp\UniversityMS.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
    End Sub

    Public Function getData(query As String) As DataTable
        Dim cmd As SqlCommand = New SqlCommand(query, con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)
        Return dt
    End Function
    Public Function addOrDeleteData(query As String) As Boolean
        Dim added As Boolean = False
        Try
            con.Open()
            Dim cmd As SqlCommand = New SqlCommand(query, con)
            cmd.ExecuteNonQuery()
            con.Close()
            added = True
        Catch
            added = False
        End Try
        Return added
    End Function

    Public Sub Close()
        con.Close()
    End Sub



End Class
