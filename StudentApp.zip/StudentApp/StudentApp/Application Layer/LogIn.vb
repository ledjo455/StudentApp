﻿Imports System.Data.SqlClient
Public Class LogIn
    Public isAdmin As Boolean = False
    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try


            If (chkAdmin.CheckState) Then
                'user is an admin
                If (checkCredentialsForAdmin(txtId.Text, txtPassword.Text)) Then
                    isAdmin = True
                    AdministratorWindow.Show()
                    Me.Hide()
                Else
                    lblError.Text = "Wrong Credentials!"
                    lblError.Visible = True
                End If
            Else
                'user is a student
                Dim id As Integer = Integer.Parse(txtId.Text)
                If (checkCredentialsForStudent(id, txtPassword.Text)) Then
                    MainWindow.Show()
                    Me.Hide()
                Else
                    lblError.Text = "Wrong Credentials!"
                    lblError.Visible = True
                End If
            End If
        Catch
            lblError.Text = "Please fill the data correctly! Only Students must enter with their IDs." & ControlChars.NewLine & " Administrators must use their usernames!"
            lblError.Visible = True
        End Try

    End Sub

    Private Sub StudentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles StudentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.StudentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.UniversityMSDataSet)

    End Sub

    Private Sub LogIn_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Student' table. You can move, or remove it, as needed.
        Me.StudentTableAdapter.Fill(Me.UniversityMSDataSet.Student)

    End Sub

    Private Sub FilterDataToolStripButton_Click(sender As Object, e As EventArgs) Handles FilterDataToolStripButton.Click
        Try
            Me.StudentTableAdapter.FilterData(Me.UniversityMSDataSet.Student, CType(IdToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Function checkCredentialsForAdmin(username As String, password As String) As Boolean
        'Try
        Dim dbcon As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from administrators where Username='" & username & "' and Password='" & password & "'"
        Dim dt As DataTable = dbcon.getData(query)
        dbcon.Close()
        If (dt.Rows.Count = 1) Then
            MainWindow.userID = dt.Rows.Item(0).Item(0)
            MainWindow.userName = dt.Rows.Item(0).Item(1)
            MainWindow.userSurname = dt.Rows.Item(0).Item(2)
            'MessageBox.Show(txtId.Text & dt.Rows.Item(0).Item(1) & dt.Rows.Item(0).Item(2) &
            'dt.Rows.Item(0).Item(3) & dt.Rows.Item(0).Item(4))
            Dim id As Integer = dt.Rows.Item(0).Item(0)
            Dim name As String = dt.Rows.Item(0).Item(1)
            Dim surname As String = dt.Rows.Item(0).Item(2)
            Dim usr As String = dt.Rows.Item(0).Item(3)
            Dim pwd As String = dt.Rows.Item(0).Item(4)
            'MainWindow.user = New Student(id, name, surname, age, major, minor, password)
            Dim user As Administrator = New Administrator(id, name, surname, usr, pwd)
            isAdmin = True
            AdministratorWindow.SetUser(user)
            'MainWindow.user = user
            Return True
        Else
            Return False
        End If
        'Catch
        Return False
        'End Try


    End Function

    Private Function checkCredentialsForStudent(id As Integer, pwd As String) As Boolean
        Try
            Dim dbcon As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            Dim query As String = "select * from student where ID=" & id & "and Password='" & pwd & "'"
            Dim dt As DataTable = dbcon.getData(query)
            dbcon.Close()
            If (dt.Rows.Count = 1) Then
                MainWindow.userID = Integer.Parse(txtId.Text)
                MainWindow.userName = dt.Rows.Item(0).Item(1)
                MainWindow.userSurname = dt.Rows.Item(0).Item(2)
                'MessageBox.Show(Integer.Parse(Integer.Parse(txtId.Text)) & dt.Rows.Item(0).Item(1) & dt.Rows.Item(0).Item(2) &
                'dt.Rows.Item(0).Item(3) & dt.Rows.Item(0).Item(4) &
                'dt.Rows.Item(0).Item(5) & dt.Rows.Item(0).Item(6))
                Dim name As String = dt.Rows.Item(0).Item(1)
                Dim surname As String = dt.Rows.Item(0).Item(2)
                Dim age As Integer = Integer.Parse(dt.Rows.Item(0).Item(3))
                Dim major As String = dt.Rows.Item(0).Item(4)
                Dim minor As String = dt.Rows.Item(0).Item(5)
                Dim password As String = dt.Rows.Item(0).Item(6)
                'MainWindow.user = New Student(id, name, surname, age, major, minor, password)
                Dim user As Student = New Student(id, name, surname, age, major, minor, password)

                MainWindow.user = user
                Return True
            Else
                Return False
            End If
        Catch
            Return False
        End Try
    End Function

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class