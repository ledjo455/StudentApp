﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Search_And_Delete_Comment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.CommentsGridView = New System.Windows.Forms.DataGridView()
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.CommentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CommentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CommentTableAdapter()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.txtCommentID = New System.Windows.Forms.TextBox()
        Me.lblStudentComment = New System.Windows.Forms.Label()
        Me.txtBoxInfo = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.CommentsGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CommentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CommentsGridView
        '
        Me.CommentsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CommentsGridView.Location = New System.Drawing.Point(35, 22)
        Me.CommentsGridView.Name = "CommentsGridView"
        Me.CommentsGridView.RowHeadersWidth = 51
        Me.CommentsGridView.RowTemplate.Height = 24
        Me.CommentsGridView.Size = New System.Drawing.Size(662, 302)
        Me.CommentsGridView.TabIndex = 0
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CommentBindingSource
        '
        Me.CommentBindingSource.DataMember = "Comment"
        Me.CommentBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'CommentTableAdapter
        '
        Me.CommentTableAdapter.ClearBeforeFill = True
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnDelete.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(872, 285)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(153, 50)
        Me.btnDelete.TabIndex = 5
        Me.btnDelete.Text = "Delete All"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'txtCommentID
        '
        Me.txtCommentID.Location = New System.Drawing.Point(960, 238)
        Me.txtCommentID.Name = "txtCommentID"
        Me.txtCommentID.Size = New System.Drawing.Size(100, 22)
        Me.txtCommentID.TabIndex = 6
        '
        'lblStudentComment
        '
        Me.lblStudentComment.AutoSize = True
        Me.lblStudentComment.Location = New System.Drawing.Point(725, 419)
        Me.lblStudentComment.Name = "lblStudentComment"
        Me.lblStudentComment.Size = New System.Drawing.Size(12, 17)
        Me.lblStudentComment.TabIndex = 8
        Me.lblStudentComment.Text = " "
        Me.lblStudentComment.Visible = False
        '
        'txtBoxInfo
        '
        Me.txtBoxInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxInfo.Location = New System.Drawing.Point(758, 86)
        Me.txtBoxInfo.Name = "txtBoxInfo"
        Me.txtBoxInfo.Size = New System.Drawing.Size(230, 125)
        Me.txtBoxInfo.TabIndex = 10
        Me.txtBoxInfo.Text = "In order to delete a student, all previous comments must be deleted. Select a stu" &
    "dent:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(822, 238)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 25)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Student ID:"
        '
        'Search_And_Delete_Comment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.comments
        Me.ClientSize = New System.Drawing.Size(1188, 521)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtBoxInfo)
        Me.Controls.Add(Me.lblStudentComment)
        Me.Controls.Add(Me.txtCommentID)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.CommentsGridView)
        Me.Name = "Search_And_Delete_Comment"
        Me.Text = "Search_And_Delete_Comment"
        CType(Me.CommentsGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CommentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CommentsGridView As DataGridView
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents CommentBindingSource As BindingSource
    Friend WithEvents CommentTableAdapter As UniversityMSDataSetTableAdapters.CommentTableAdapter
    Friend WithEvents btnDelete As Button
    Friend WithEvents txtCommentID As TextBox
    Friend WithEvents lblStudentComment As Label
    Friend WithEvents txtBoxInfo As RichTextBox
    Friend WithEvents Label1 As Label
End Class
