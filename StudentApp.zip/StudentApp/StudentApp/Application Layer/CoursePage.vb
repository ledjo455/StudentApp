﻿Imports System.Data.SqlClient
Public Class CoursePage
    Private Sub CoursePage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dataGridViewParticipants.ClearSelection()
        txtComments.DeselectAll()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select s.Name, s.Surname from StudentCourse sc join student s on sc.StudentID=s.ID where sc.CourseID=" & MainWindow.courseID
        Dim dt As DataTable = con.getData(query)
        con.Close()
        dataGridViewParticipants.DataSource = dt
        fillCommentsTextBox()
        'TODO: This line of code loads data into the 'UniversityMSDataSet.StudentCourse' table. You can move, or remove it, as needed.
        Me.StudentCourseTableAdapter.Fill(Me.UniversityMSDataSet.StudentCourse)
        Dim courseID As Integer = MainWindow.courseID
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Comment' table. You can move, or remove it, as needed.
        Me.CommentTableAdapter.Fill(Me.UniversityMSDataSet.Comment)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.FillBy(Me.UniversityMSDataSet.Course, courseID)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Student' table. You can move, or remove it, as needed.
        Me.StudentTableAdapter.Fill(Me.UniversityMSDataSet.Student)



    End Sub



    Private Sub InstructorTextBox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub InstructorLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.CourseTableAdapter.FillBy(Me.UniversityMSDataSet.Course, CType(ParameterToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub DisplayCourseStudentsToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.StudentTableAdapter.DisplayCourseStudents(Me.UniversityMSDataSet.Student)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub FillByToolStripButton1_Click(sender As Object, e As EventArgs)
        Try
            Me.StudentTableAdapter.FillBy(Me.UniversityMSDataSet.Student)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub CommentBtn_Click(sender As Object, e As EventArgs) Handles commentBtn.Click
        If txtComments.Text <> "" Then
            Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            Dim query As String = "INSERT INTO comment (StudentID, CourseID, Text) VALUES (" & MainWindow.userID & ", " & MainWindow.courseID & ", '" & txtAddComment.Text & "');"
            If con.addOrDeleteData(query) Then
                lblInfo.Visible = True
                fillCommentsTextBox() 'refresh the comments textbox
            Else
                lblInfo.Visible = True
                lblInfo.Text = "Error! Try Again!"
                lblInfo.ForeColor = Color.Red
            End If
            con.Close()
        Else
            lblInfo.Visible = True
            lblInfo.Text = "Write something!"
            lblInfo.ForeColor = Color.Red
        End If


    End Sub

    Private Sub fillCommentsTextBox()
        txtComments.Text = ""
        Dim query As String = "SELECT c.Text,s.Name,s.Surname " & "FROM comment c join student s on c.StudentID=s.ID " & "where c.CourseID=" & MainWindow.courseID
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim table As DataTable = con.getData(query)
        Dim output As String = ""
        If table.Rows.Count > 0 Then

            For index = 0 To table.Rows.Count - 1
                output = output & table.Rows.Item(index).Item(1) & "  " &
                    table.Rows.Item(index).Item(2) & ": " & ControlChars.NewLine &
                    table.Rows.Item(index).Item(0) & ControlChars.NewLine & ControlChars.NewLine
            Next index

            txtComments.Text = output
            con.Close()
        End If

    End Sub
End Class