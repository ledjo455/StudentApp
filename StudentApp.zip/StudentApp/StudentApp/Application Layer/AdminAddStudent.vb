﻿Imports System.Text.RegularExpressions

Public Class AdminAddStudent
    Private Sub AdminAddStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Department' table. You can move, or remove it, as needed.
        Me.DepartmentTableAdapter.FillByDistinctDepartment(Me.UniversityMSDataSet.Department)
        FIllMinorCombo()
    End Sub

    Private Sub FIllMinorCombo()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select distinct department from course"
        Dim data As DataTable = con.getData(query)
        cmbMinor.Items.Add("-")
        For i As Integer = 0 To data.Rows.Count - 1
            cmbMinor.Items.Add(data.Rows.Item(i).Item(0))
        Next
        cmbMinor.SelectedIndex = 0
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim name As String = If(txtName.Text <> String.Empty, txtName.Text, "")
        Dim surname As String = If(txtSurname.Text <> String.Empty, txtSurname.Text, "")
        Dim password As String = If(txtPassword.Text <> String.Empty, txtPassword.Text, "")
        Dim age1 As Integer
        Dim age As String = If(Integer.TryParse(txtAge.Text, age1) And age1 > 18, txtAge.Text, "")
        Dim selectedRowFac As DataRowView = cmbMajor.SelectedItem
        Dim row1 = selectedRowFac.Row
        Dim major As String = row1.Item(0)

        'Dim selectedRowDep As DataRowView = cmbMinor.SelectedItem
        'Dim row2 = selectedRowDep.Row
        Dim minor As String = cmbMinor.SelectedItem



        If name = "" Or surname = "" Or age = "" Or password = "" Then
            MessageBox.Show("Wrong data entered!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            'user has entered all data
            Dim newStudent As Student = New Student(-1, name, surname, age1, major, minor, password)
            If Student.AddStudent(newStudent) Then 'course added succesfully
                MessageBox.Show("Student added succesfully!", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Information)
                AdministratorWindow.FillLabels()
            Else 'database error occured
                MessageBox.Show("Database error!", "Add Student", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        End If
    End Sub


End Class