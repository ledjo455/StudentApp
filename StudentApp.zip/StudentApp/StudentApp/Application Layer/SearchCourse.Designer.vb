﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.addBtn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDropCourse = New System.Windows.Forms.TextBox()
        Me.dropBtn = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtAddCourse = New System.Windows.Forms.TextBox()
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.CourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CourseTableAdapter()
        Me.CourseDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Department = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Faculty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Eligibility = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourseListDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FillAllPossibilitiesToolStrip = New System.Windows.Forms.ToolStrip()
        Me.Parameter1ToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.Parameter1ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.Parameter2ToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.Parameter2ToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillAllPossibilitiesToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.UniversityMSDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableAdapterManager = New StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseListDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillAllPossibilitiesToolStrip.SuspendLayout()
        CType(Me.UniversityMSDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 27)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 29)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Course List"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(216, 41)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(251, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "(only courses in your major and minor)"
        '
        'addBtn
        '
        Me.addBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.addBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addBtn.ForeColor = System.Drawing.Color.White
        Me.addBtn.Location = New System.Drawing.Point(375, 410)
        Me.addBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.addBtn.Name = "addBtn"
        Me.addBtn.Size = New System.Drawing.Size(161, 43)
        Me.addBtn.TabIndex = 13
        Me.addBtn.Text = "Add Course"
        Me.addBtn.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(32, 490)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(185, 29)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "My Course List"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(35, 754)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(164, 24)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Enter Course ID:"
        '
        'txtDropCourse
        '
        Me.txtDropCourse.Enabled = False
        Me.txtDropCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDropCourse.Location = New System.Drawing.Point(235, 751)
        Me.txtDropCourse.Margin = New System.Windows.Forms.Padding(4)
        Me.txtDropCourse.Name = "txtDropCourse"
        Me.txtDropCourse.Size = New System.Drawing.Size(132, 29)
        Me.txtDropCourse.TabIndex = 17
        '
        'dropBtn
        '
        Me.dropBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.dropBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dropBtn.ForeColor = System.Drawing.Color.White
        Me.dropBtn.Location = New System.Drawing.Point(395, 742)
        Me.dropBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.dropBtn.Name = "dropBtn"
        Me.dropBtn.Size = New System.Drawing.Size(169, 38)
        Me.dropBtn.TabIndex = 18
        Me.dropBtn.Text = "Drop Course"
        Me.dropBtn.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(35, 423)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(164, 24)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Enter Course ID:"
        '
        'txtAddCourse
        '
        Me.txtAddCourse.Enabled = False
        Me.txtAddCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddCourse.Location = New System.Drawing.Point(220, 416)
        Me.txtAddCourse.Margin = New System.Windows.Forms.Padding(4)
        Me.txtAddCourse.Name = "txtAddCourse"
        Me.txtAddCourse.Size = New System.Drawing.Size(132, 29)
        Me.txtAddCourse.TabIndex = 20
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'CourseDataGridView
        '
        Me.CourseDataGridView.AllowUserToAddRows = False
        Me.CourseDataGridView.AllowUserToDeleteRows = False
        Me.CourseDataGridView.AutoGenerateColumns = False
        Me.CourseDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.CourseDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.CourseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CourseDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.Department, Me.Faculty, Me.Eligibility})
        Me.CourseDataGridView.DataSource = Me.CourseBindingSource
        Me.CourseDataGridView.Location = New System.Drawing.Point(27, 544)
        Me.CourseDataGridView.Margin = New System.Windows.Forms.Padding(4)
        Me.CourseDataGridView.Name = "CourseDataGridView"
        Me.CourseDataGridView.ReadOnly = True
        Me.CourseDataGridView.RowHeadersWidth = 51
        Me.CourseDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.CourseDataGridView.Size = New System.Drawing.Size(1395, 161)
        Me.CourseDataGridView.TabIndex = 20
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Title"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Title"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Instructor"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Instructor"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Credits"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Credits"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Day"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Day"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Time"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Time"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Class"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Class"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'Department
        '
        Me.Department.DataPropertyName = "Department"
        Me.Department.HeaderText = "Department"
        Me.Department.MinimumWidth = 6
        Me.Department.Name = "Department"
        Me.Department.ReadOnly = True
        '
        'Faculty
        '
        Me.Faculty.DataPropertyName = "Faculty"
        Me.Faculty.HeaderText = "Faculty"
        Me.Faculty.MinimumWidth = 6
        Me.Faculty.Name = "Faculty"
        Me.Faculty.ReadOnly = True
        '
        'Eligibility
        '
        Me.Eligibility.DataPropertyName = "Eligibility"
        Me.Eligibility.HeaderText = "Eligibility"
        Me.Eligibility.MinimumWidth = 6
        Me.Eligibility.Name = "Eligibility"
        Me.Eligibility.ReadOnly = True
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'CourseListDataGridView
        '
        Me.CourseListDataGridView.AllowUserToAddRows = False
        Me.CourseListDataGridView.AllowUserToDeleteRows = False
        Me.CourseListDataGridView.AutoGenerateColumns = False
        Me.CourseListDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.CourseListDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.CourseListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CourseListDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17})
        Me.CourseListDataGridView.DataSource = Me.CourseBindingSource
        Me.CourseListDataGridView.Location = New System.Drawing.Point(16, 80)
        Me.CourseListDataGridView.Margin = New System.Windows.Forms.Padding(4)
        Me.CourseListDataGridView.Name = "CourseListDataGridView"
        Me.CourseListDataGridView.ReadOnly = True
        Me.CourseListDataGridView.RowHeadersWidth = 51
        Me.CourseListDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.CourseListDataGridView.Size = New System.Drawing.Size(1405, 300)
        Me.CourseListDataGridView.TabIndex = 21
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn8.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Title"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Title"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Instructor"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Instructor"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "Credits"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Credits"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Day"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Day"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "Time"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Time"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "Class"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Class"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "Department"
        Me.DataGridViewTextBoxColumn15.HeaderText = "Department"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "Faculty"
        Me.DataGridViewTextBoxColumn16.HeaderText = "Faculty"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "Eligibility"
        Me.DataGridViewTextBoxColumn17.HeaderText = "Eligibility"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        '
        'FillAllPossibilitiesToolStrip
        '
        Me.FillAllPossibilitiesToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FillAllPossibilitiesToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Parameter1ToolStripLabel, Me.Parameter1ToolStripTextBox, Me.Parameter2ToolStripLabel, Me.Parameter2ToolStripTextBox, Me.FillAllPossibilitiesToolStripButton})
        Me.FillAllPossibilitiesToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.FillAllPossibilitiesToolStrip.Name = "FillAllPossibilitiesToolStrip"
        Me.FillAllPossibilitiesToolStrip.Size = New System.Drawing.Size(1589, 31)
        Me.FillAllPossibilitiesToolStrip.TabIndex = 22
        Me.FillAllPossibilitiesToolStrip.Text = "FillAllPossibilitiesToolStrip"
        Me.FillAllPossibilitiesToolStrip.Visible = False
        '
        'Parameter1ToolStripLabel
        '
        Me.Parameter1ToolStripLabel.Name = "Parameter1ToolStripLabel"
        Me.Parameter1ToolStripLabel.Size = New System.Drawing.Size(89, 28)
        Me.Parameter1ToolStripLabel.Text = "parameter1:"
        '
        'Parameter1ToolStripTextBox
        '
        Me.Parameter1ToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Parameter1ToolStripTextBox.Name = "Parameter1ToolStripTextBox"
        Me.Parameter1ToolStripTextBox.Size = New System.Drawing.Size(132, 31)
        '
        'Parameter2ToolStripLabel
        '
        Me.Parameter2ToolStripLabel.Name = "Parameter2ToolStripLabel"
        Me.Parameter2ToolStripLabel.Size = New System.Drawing.Size(89, 28)
        Me.Parameter2ToolStripLabel.Text = "parameter2:"
        '
        'Parameter2ToolStripTextBox
        '
        Me.Parameter2ToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Parameter2ToolStripTextBox.Name = "Parameter2ToolStripTextBox"
        Me.Parameter2ToolStripTextBox.Size = New System.Drawing.Size(132, 31)
        '
        'FillAllPossibilitiesToolStripButton
        '
        Me.FillAllPossibilitiesToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillAllPossibilitiesToolStripButton.Name = "FillAllPossibilitiesToolStripButton"
        Me.FillAllPossibilitiesToolStripButton.Size = New System.Drawing.Size(126, 28)
        Me.FillAllPossibilitiesToolStripButton.Text = "FillAllPossibilities"
        '
        'UniversityMSDataSetBindingSource
        '
        Me.UniversityMSDataSetBindingSource.DataSource = Me.UniversityMSDataSet
        Me.UniversityMSDataSetBindingSource.Position = 0
        '
        'TableAdapterManager
        '
        'Me.TableAdapterManager.AdministratorsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CommentTableAdapter = Nothing
        Me.TableAdapterManager.Connection = Nothing
        Me.TableAdapterManager.CourseTableAdapter = Nothing
        Me.TableAdapterManager.FriendshipTableAdapter = Nothing
        Me.TableAdapterManager.StudentCourseTableAdapter = Nothing
        Me.TableAdapterManager.StudentTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'SearchCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.yale
        Me.ClientSize = New System.Drawing.Size(1457, 838)
        Me.Controls.Add(Me.FillAllPossibilitiesToolStrip)
        Me.Controls.Add(Me.CourseListDataGridView)
        Me.Controls.Add(Me.CourseDataGridView)
        Me.Controls.Add(Me.txtAddCourse)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.dropBtn)
        Me.Controls.Add(Me.txtDropCourse)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.addBtn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "SearchCourse"
        Me.Text = "SearchCourse"
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseListDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillAllPossibilitiesToolStrip.ResumeLayout(False)
        Me.FillAllPossibilitiesToolStrip.PerformLayout()
        CType(Me.UniversityMSDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents addBtn As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtDropCourse As TextBox
    Friend WithEvents dropBtn As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents txtAddCourse As TextBox
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents UniversityMSDataSetBindingSource As BindingSource
    Friend WithEvents CourseBindingSource As BindingSource
    Friend WithEvents CourseTableAdapter As UniversityMSDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents TableAdapterManager As UniversityMSDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CourseDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents Department As DataGridViewTextBoxColumn
    Friend WithEvents Faculty As DataGridViewTextBoxColumn
    Friend WithEvents Eligibility As DataGridViewTextBoxColumn
    Friend WithEvents CourseListDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents FillAllPossibilitiesToolStrip As ToolStrip
    Friend WithEvents Parameter1ToolStripLabel As ToolStripLabel
    Friend WithEvents Parameter1ToolStripTextBox As ToolStripTextBox
    Friend WithEvents Parameter2ToolStripLabel As ToolStripLabel
    Friend WithEvents Parameter2ToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillAllPossibilitiesToolStripButton As ToolStripButton
End Class
