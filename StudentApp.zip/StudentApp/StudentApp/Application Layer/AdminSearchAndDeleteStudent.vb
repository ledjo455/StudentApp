﻿Public Class AdminSearchAndDeleteStudent
    Private Sub AdminSearchAndDeleteStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Student' table. You can move, or remove it, as needed.
        Me.StudentTableAdapter.Fill(Me.UniversityMSDataSet.Student)
        fillGridView()
    End Sub

    Private Sub DataGridViewStudents_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridViewStudents.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DataGridViewStudents.Rows(index)
        txtStudentID.Text = selectedRow.Cells(0).Value.ToString()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        If txtNameSearch.Text <> String.Empty And txtSurnameSearch.Text <> String.Empty Then
            displayDataSearchByNameOrSurnamer(txtNameSearch.Text, txtSurnameSearch.Text)
        ElseIf (txtNameSearch.Text <> String.Empty) Then
            displayDataSearchByName(txtNameSearch.Text)
        ElseIf (txtSurnameSearch.Text <> String.Empty) Then
            displayDataSearchBySurname(txtSurnameSearch.Text)
        End If
    End Sub

    Private Sub displayDataSearchBySurname(surname As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from student where surname like '" & surname & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewStudents.DataSource = dt
    End Sub


    Private Sub displayDataSearchByName(name As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from student where name like '" & name & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewStudents.DataSource = dt
    End Sub

    Private Sub displayDataSearchByNameOrSurnamer(name As String, surname As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from student where name like '" & name & "%' or surname like '" & surname & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewStudents.DataSource = dt
    End Sub

    Private Sub BtnDisplayAll_Click(sender As Object, e As EventArgs) Handles btnDisplayAll.Click
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from student"
        Dim dt As DataTable = con.getData(query)

        DataGridViewStudents.DataSource = dt
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtStudentID.Text <> String.Empty Then
            'Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            'Dim query As String = "delete from student where id=" & Integer.Parse(txtStudentID.Text)
            If Student.DeleteStudent(Integer.Parse(txtStudentID.Text)) Then
                lblInfo.Text = "Student deleted succesfully!"
                lblInfo.Visible = True
                AdministratorWindow.FillLabels()
            Else
                lblInfo.Text = "Student could not be deleted!"
                lblInfo.Visible = True
            End If
        End If
    End Sub

    Private Sub fillGridView()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from student"
        Dim dt As DataTable = con.getData(query)

        DataGridViewStudents.DataSource = dt
    End Sub

    Private Sub DataGridViewStudents_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridViewStudents.CellContentClick

    End Sub

    Private Sub txtStudentID_TextChanged(sender As Object, e As EventArgs) Handles txtStudentID.TextChanged

    End Sub
End Class