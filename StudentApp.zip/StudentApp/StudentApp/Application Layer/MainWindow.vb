﻿
Public Class MainWindow
    Public userID As Integer
    Public userName As String
    Public userSurname As String
    Public courseID As Integer
    Public user As Student
    Private Sub searchBtn_Click(sender As Object, e As EventArgs) Handles searchBtn.Click
        Dim newForm = New SearchCourse
        newForm.Show()
    End Sub

    Private Sub detailsBtn_Click(sender As Object, e As EventArgs) Handles detailsBtn.Click
        Dim newForm = New CourseDetails
        newForm.Show()
    End Sub

    Private Sub allStudentsBtn_Click(sender As Object, e As EventArgs) Handles allStudentsBtn.Click
        Dim newForm = New AllStudentsWindow
        newForm.Show()
    End Sub

    Private Sub friendsBtn_Click(sender As Object, e As EventArgs) Handles friendsBtn.Click
        Dim newForm = New FriendsList
        newForm.Show()
    End Sub

    Private Sub logoutBtn_Click(sender As Object, e As EventArgs) Handles logoutBtn.Click
        Dim options As DialogResult
        options = MessageBox.Show("Are you sure you want to log out?", "Log Out",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If options = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub courseBtn_Click(sender As Object, e As EventArgs) Handles btnCourse.Click
        CoursePage.Show()

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Dim newForm = New HelpAndSupport
        newForm.Show()
    End Sub

    Private Sub CourseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.UniversityMSDataSet)

    End Sub

    Private Sub MainWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblWelcome.Text = "Welcome" & ControlChars.NewLine & userName & " " & userSurname
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.
        'Me.CourseTableAdapter.DisplayCoursesOfUser(Me.UniversityMSDataSet.Course, userID)
        'Me.CourseTableAdapter.Fill(Me.UniversityMSDataSet.Course)
        'CourseDataGridView.ClearSelection()

        fillTheCourseTable()
    End Sub


    Private Sub DisplayCoursesOfUserToolStripButton_Click(sender As Object, e As EventArgs) Handles DisplayCoursesOfUserToolStripButton.Click
        Try
            Me.CourseTableAdapter.DisplayCoursesOfUser(Me.UniversityMSDataSet.Course, CType(StudentIDToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub CourseDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles CourseDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = CourseDataGridView.Rows(index)
        txtCourseID.Text = selectedRow.Cells(0).Value.ToString()
        courseID = Integer.Parse(selectedRow.Cells(0).Value.ToString())

    End Sub

    Private Sub CourseDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles CourseDataGridView.CellContentClick

    End Sub

    Private Sub RefreshBtn_Click(sender As Object, e As EventArgs) Handles refreshBtn.Click
        'CourseTableAdapter.DisplayCoursesOfUser(Me.UniversityMSDataSet.Course, userID) 'refilling the table
        fillTheCourseTable()

    End Sub

    Public Sub fillTheCourseTable()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query2 As String = "SELECT c.ID, c.Title, c.Instructor, c.Credits, c.Day, c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
FROM  Course AS c INNER JOIN
                         StudentCourse AS sc ON c.ID = sc.CourseID
WHERE        (sc.StudentID =" & userID & ")"
        Dim table2 As DataTable = con.getData(query2)
        CourseDataGridView.DataSource = table2
        con.Close()
        CourseDataGridView.ClearSelection()

    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub
End Class