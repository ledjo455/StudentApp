﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FriendsList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.friendsDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.friendCoursesDataGridView = New System.Windows.Forms.DataGridView()
        Me.lblFriendID = New System.Windows.Forms.Label()
        Me.lblCourseID = New System.Windows.Forms.Label()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        CType(Me.friendsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.friendCoursesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(28, 22)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(180, 29)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Friends Table:"
        '
        'friendsDataGridView
        '
        Me.friendsDataGridView.AllowUserToAddRows = False
        Me.friendsDataGridView.AllowUserToDeleteRows = False
        Me.friendsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.friendsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.friendsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.friendsDataGridView.Location = New System.Drawing.Point(32, 73)
        Me.friendsDataGridView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.friendsDataGridView.Name = "friendsDataGridView"
        Me.friendsDataGridView.ReadOnly = True
        Me.friendsDataGridView.RowHeadersWidth = 51
        Me.friendsDataGridView.Size = New System.Drawing.Size(1073, 196)
        Me.friendsDataGridView.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 332)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Friend ID:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(535, 332)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Course ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label4.Location = New System.Drawing.Point(28, 406)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(216, 29)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Friends Courses:"
        '
        'friendCoursesDataGridView
        '
        Me.friendCoursesDataGridView.AllowUserToAddRows = False
        Me.friendCoursesDataGridView.AllowUserToDeleteRows = False
        Me.friendCoursesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.friendCoursesDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.friendCoursesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.friendCoursesDataGridView.Location = New System.Drawing.Point(59, 469)
        Me.friendCoursesDataGridView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.friendCoursesDataGridView.Name = "friendCoursesDataGridView"
        Me.friendCoursesDataGridView.ReadOnly = True
        Me.friendCoursesDataGridView.RowHeadersWidth = 51
        Me.friendCoursesDataGridView.Size = New System.Drawing.Size(1027, 230)
        Me.friendCoursesDataGridView.TabIndex = 12
        '
        'lblFriendID
        '
        Me.lblFriendID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFriendID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFriendID.Location = New System.Drawing.Point(144, 330)
        Me.lblFriendID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFriendID.Name = "lblFriendID"
        Me.lblFriendID.Size = New System.Drawing.Size(133, 28)
        Me.lblFriendID.TabIndex = 13
        '
        'lblCourseID
        '
        Me.lblCourseID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCourseID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourseID.Location = New System.Drawing.Point(661, 330)
        Me.lblCourseID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCourseID.Name = "lblCourseID"
        Me.lblCourseID.Size = New System.Drawing.Size(133, 28)
        Me.lblCourseID.TabIndex = 14
        '
        'btnAddCourse
        '
        Me.btnAddCourse.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnAddCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddCourse.ForeColor = System.Drawing.Color.White
        Me.btnAddCourse.Location = New System.Drawing.Point(952, 315)
        Me.btnAddCourse.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(153, 58)
        Me.btnAddCourse.TabIndex = 15
        Me.btnAddCourse.Text = "Add Courses"
        Me.btnAddCourse.UseVisualStyleBackColor = False
        '
        'FriendsList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.blur
        Me.ClientSize = New System.Drawing.Size(1159, 747)
        Me.Controls.Add(Me.btnAddCourse)
        Me.Controls.Add(Me.lblCourseID)
        Me.Controls.Add(Me.lblFriendID)
        Me.Controls.Add(Me.friendCoursesDataGridView)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.friendsDataGridView)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "FriendsList"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Friends List"
        CType(Me.friendsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.friendCoursesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents friendsDataGridView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents friendCoursesDataGridView As DataGridView
    Friend WithEvents lblFriendID As Label
    Friend WithEvents lblCourseID As Label
    Friend WithEvents btnAddCourse As Button
End Class
