﻿Public Class FriendsList
    Private Sub FriendsList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillFriendsTable()
    End Sub

    Private Sub fillFriendsTable()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "SELECT s1.ID, s1.Name, s1.Surname, s1.Major, s1.Minor 
                               FROM Student AS s INNER JOIN
                               Friendship AS f ON s.ID = f.StudentID INNER JOIN
                               Student AS s1 ON s1.ID = f.FriendID
                               WHERE (s.ID =" & MainWindow.userID & ")"
        Dim table As DataTable = con.getData(query)
        friendsDataGridView.DataSource = table
        con.Close()
    End Sub

    Private Sub FriendsDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles friendsDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = friendsDataGridView.Rows(index)
        lblFriendID.Text = selectedRow.Cells(0).Value.ToString()
        Dim friendID As Integer = Integer.Parse(lblFriendID.Text)
        fillFriendCourseTable(friendID)
    End Sub

    Private Sub fillFriendCourseTable(ByVal studentID As Integer)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select c.ID, TITLE, INSTRUCTOR, CREDITS, DEPARTMENT, FACULTY, ELIGIBILITY from course c join studentcourse sc on c.id=sc.courseID where sc.StudentID=" & studentID
        Dim table As DataTable = con.getData(query)
        friendCoursesDataGridView.DataSource = table
        friendCoursesDataGridView.ClearSelection()
        con.Close()


    End Sub

    Private Sub FriendCoursesDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles friendCoursesDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = friendCoursesDataGridView.Rows(index)
        lblCourseID.Text = selectedRow.Cells(0).Value.ToString()
    End Sub

    Private Sub BtnAddCourse_Click(sender As Object, e As EventArgs) Handles btnAddCourse.Click
        Dim courseID As Integer
        If Integer.TryParse(lblCourseID.Text, courseID) Then
            'check if the user has already the course
            Dim query As String = "SELECT c.ID, c.Title, c.Instructor, c.Credits, c.Day,                            c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
                                   From Course As c INNER Join                                            StudentCourse As sc On c.ID = sc.CourseID INNER Join
                                   Student As s On sc.StudentID = s.ID
                                   Where (s.ID =" & MainWindow.userID & ") AND
                                   (c.ID = " & courseID & ")"
            Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            Dim table As DataTable = con.getData(query)
            Dim isFound As Boolean = False
            For index = 0 To table.Rows.Count - 1
                If table.Rows.Item(index).Item(0) = courseID Then
                    'the user has the course he/she is trying to add
                    MessageBox.Show("This course cannot be added because it is already on your course list!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    isFound = True
                    Exit For
                End If
            Next index
            'add the course
            If Not isFound And isEligibleToTake(courseID) Then

                Dim insertQuery As String = "INSERT INTO studentcourse (StudentID, CourseID) VALUES (" & MainWindow.userID & ", " & courseID & ");"
                If con.addOrDeleteData(insertQuery) Then 'data added succesfully
                    MessageBox.Show("Course added succesfully! Refresh the table in the main window!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Information)

                End If
            Else
                MessageBox.Show("You either have this course or you are not eligible to  add it!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

            con.Close()
        Else 'nothing added
            MessageBox.Show("Wrong Course ID! Enter again or select from the table!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Function isEligibleToTake(ByVal courseID As Integer) As Boolean
        Dim query As String = "SELECT DISTINCT c.ID, c.Title, c.Instructor, c.Credits, c.Day,                       c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
                               FROM Course AS c INNER JOIN
                               StudentCourse AS sc ON c.ID = sc.CourseID INNER JOIN
                               Student AS s ON sc.StudentID = s.ID
                               WHERE (c.Eligibility = 'All') AND (c.ID =" & courseID & ") OR
                               (c.ID =" & courseID & ") AND (c.Department = '" & MainWindow.user.MajorProperty & "') OR
                         (c.ID =" & courseID & ") AND (c.Department ='" & MainWindow.user.MinorProperty & "') AND (sc.studentID=" & MainWindow.userID & ")"
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim table As DataTable = con.getData(query)

        If table.Rows.Count = 1 Then 'student is elgible to take
            con.Close()
            Return True
        Else
            con.Close()
            Return False
        End If

    End Function

    Private Sub ShowBtn_Click(sender As Object, e As EventArgs)

    End Sub
End Class