﻿Imports System.Text.RegularExpressions

Public Class AdminAddCourse
    Private Sub CourseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.UniversityMSDataSet)

    End Sub

    Private Sub AdminAddCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Faculty' table. You can move, or remove it, as needed.
        Me.FacultyTableAdapter.FillByFaculty(Me.UniversityMSDataSet.Faculty)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Department' table. You can move, or remove it, as needed.
        Me.DepartmentTableAdapter.FillByDistinctDepartment(Me.UniversityMSDataSet.Department)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course1' table. You can move, or remove it, as needed.
        'Me.Course1TableAdapter.FillByFaculty(Me.UniversityMSDataSet.Course1)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Comment' table. You can move, or remove it, as needed.
        Me.CommentTableAdapter.Fill(Me.UniversityMSDataSet.Comment)
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.UniversityMSDataSet.Course)
        cmbEligibility.SelectedIndex = 1
        DayComboBox.SelectedIndex = 0

    End Sub

    Private Sub FillByEligibilityDistinctToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.CourseTableAdapter.FillByEligibilityDistinct(Me.UniversityMSDataSet.Course)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim title As String = If(txtTitle.Text <> String.Empty, txtTitle.Text, "")
        Dim instructor As String = If(Regex.IsMatch(txtInstructor.Text, "^[A-Z]{1}[a-z]* [A-Z]{1}[a-z]*$"), txtInstructor.Text, "")
        Dim time As String = If(Regex.IsMatch(txtTime.Text, "^[0-9]{2}:[0-9]{2}-[0-9]{2}:[0-9]{2}$"), txtTime.Text, "")
        Dim location As String = If(txtLocation.Text <> String.Empty, txtLocation.Text, "")
        Dim credits As Integer = nudCredits.Value
        Dim day As String = DayComboBox.SelectedItem
        Dim selectedRowFac As DataRowView = FacultyComboBox.SelectedItem
        Dim row1 = selectedRowFac.Row
        Dim faculty As String = row1.Item(0)

        Dim selectedRowDep As DataRowView = DepartmentComboBox.SelectedItem
        Dim row2 = selectedRowDep.Row
        Dim department As String = row2.Item(0)
        'MessageBox.Show(department)
        Dim eligibility As String = cmbEligibility.SelectedItem

        If title = "" Or instructor = "" Or time = "" Then
            MessageBox.Show("Wrong data entered!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            'user has entered all data
            If courseExists(title, instructor, day, time) Then
                MessageBox.Show("Course already exists!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                Dim newCourse As Course = New Course(-1, title, instructor, credits, day, time, location, faculty, department, eligibility)
                'Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
                'Dim query As String = "insert into course (title, instructor, credits, day, time, class, faculty, department, eligibility) values ('" & title & "','" & instructor & "'," & credits & " ,'" & day & "', '" & time & "', '" & location & "', '" & faculty & "', '" & department & "', '" & eligibility & "')"
                If Course.AddCourse(newCourse) Then 'course added succesfully
                    MessageBox.Show("Course added succesfully!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    AdministratorWindow.FillLabels()
                Else 'database error occured
                    MessageBox.Show("Database error!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If

            End If
        End If




    End Sub

    Private Function courseExists(title As String, instructor As String, day As String, time As String) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course where title='" & title & "' and instructor='" & instructor & "' and time='" & time & "' and day='" & day & "'"
        Dim dt As DataTable = con.getData(query)
        If dt.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

End Class