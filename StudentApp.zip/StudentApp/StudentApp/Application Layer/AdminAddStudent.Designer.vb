﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminAddStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label5 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim FacultyLabel As System.Windows.Forms.Label
        Dim DepartmentLabel As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.cmbMinor = New System.Windows.Forms.ComboBox()
        Me.cmbMajor = New System.Windows.Forms.ComboBox()
        Me.DepartmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.DepartmentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.DepartmentTableAdapter()
        Label5 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        FacultyLabel = New System.Windows.Forms.Label()
        DepartmentLabel = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        CType(Me.DepartmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label5.Location = New System.Drawing.Point(151, 313)
        Label5.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(62, 29)
        Label5.TabIndex = 29
        Label5.Text = "Age:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.Location = New System.Drawing.Point(135, 59)
        Label4.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(84, 29)
        Label4.TabIndex = 26
        Label4.Text = "Name:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(100, 113)
        Label2.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(116, 29)
        Label2.TabIndex = 23
        Label2.Text = "Surname:"
        '
        'FacultyLabel
        '
        FacultyLabel.AutoSize = True
        FacultyLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FacultyLabel.Location = New System.Drawing.Point(133, 239)
        FacultyLabel.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        FacultyLabel.Name = "FacultyLabel"
        FacultyLabel.Size = New System.Drawing.Size(80, 29)
        FacultyLabel.TabIndex = 21
        FacultyLabel.Text = "Minor:"
        '
        'DepartmentLabel
        '
        DepartmentLabel.AutoSize = True
        DepartmentLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DepartmentLabel.Location = New System.Drawing.Point(135, 174)
        DepartmentLabel.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        DepartmentLabel.Name = "DepartmentLabel"
        DepartmentLabel.Size = New System.Drawing.Size(80, 29)
        DepartmentLabel.TabIndex = 19
        DepartmentLabel.Text = "Major:"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(88, 379)
        Label1.Margin = New System.Windows.Forms.Padding(8, 0, 8, 0)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(126, 29)
        Label1.TabIndex = 31
        Label1.Text = "Password:"
        '
        'txtAge
        '
        Me.txtAge.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAge.Location = New System.Drawing.Point(239, 310)
        Me.txtAge.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(256, 30)
        Me.txtAge.TabIndex = 30
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.DarkOrange
        Me.btnAdd.Font = New System.Drawing.Font("Ink Free", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.White
        Me.btnAdd.Location = New System.Drawing.Point(365, 439)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(131, 59)
        Me.btnAdd.TabIndex = 28
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(239, 59)
        Me.txtName.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(256, 30)
        Me.txtName.TabIndex = 27
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(239, 379)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(256, 30)
        Me.txtPassword.TabIndex = 25
        '
        'txtSurname
        '
        Me.txtSurname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSurname.Location = New System.Drawing.Point(239, 116)
        Me.txtSurname.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(256, 30)
        Me.txtSurname.TabIndex = 24
        '
        'cmbMinor
        '
        Me.cmbMinor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbMinor.FormattingEnabled = True
        Me.cmbMinor.Location = New System.Drawing.Point(239, 239)
        Me.cmbMinor.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.cmbMinor.Name = "cmbMinor"
        Me.cmbMinor.Size = New System.Drawing.Size(256, 33)
        Me.cmbMinor.TabIndex = 22
        '
        'cmbMajor
        '
        Me.cmbMajor.DataSource = Me.DepartmentBindingSource
        Me.cmbMajor.DisplayMember = "Department"
        Me.cmbMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbMajor.FormattingEnabled = True
        Me.cmbMajor.Location = New System.Drawing.Point(239, 174)
        Me.cmbMajor.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.cmbMajor.Name = "cmbMajor"
        Me.cmbMajor.Size = New System.Drawing.Size(256, 33)
        Me.cmbMajor.TabIndex = 20
        Me.cmbMajor.ValueMember = "Department"
        '
        'DepartmentBindingSource
        '
        Me.DepartmentBindingSource.DataMember = "Department"
        Me.DepartmentBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DepartmentTableAdapter
        '
        Me.DepartmentTableAdapter.ClearBeforeFill = True
        '
        'AdminAddStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.blur
        Me.ClientSize = New System.Drawing.Size(623, 528)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Me.txtAge)
        Me.Controls.Add(Label5)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Label2)
        Me.Controls.Add(FacultyLabel)
        Me.Controls.Add(Me.cmbMinor)
        Me.Controls.Add(DepartmentLabel)
        Me.Controls.Add(Me.cmbMajor)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "AdminAddStudent"
        Me.Text = "AdminAddStudent"
        CType(Me.DepartmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtAge As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtSurname As TextBox
    Friend WithEvents cmbMinor As ComboBox
    Friend WithEvents cmbMajor As ComboBox
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents DepartmentBindingSource As BindingSource
    Friend WithEvents DepartmentTableAdapter As UniversityMSDataSetTableAdapters.DepartmentTableAdapter
End Class
