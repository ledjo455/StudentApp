﻿Public Class Search_And_Delete_Comment
    Private Sub Search_And_Delete_Comment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Comment' table. You can move, or remove it, as needed.


        fillGridView()

    End Sub


    Private Sub fillGridView()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "SELECT Student.ID, Student.Name, Comment.CourseID, Comment.Text FROM Comment INNER JOIN
                  Student ON Student.ID = Comment.StudentID"
        Dim dt As DataTable = con.getData(query)

        CommentsGridView.DataSource = dt

    End Sub



    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtCommentID.Text <> String.Empty Then
            'Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            'Dim query As String = "delete from student where id=" & Integer.Parse(txtStudentID.Text)
            If Student.DeleteComment(Integer.Parse(txtCommentID.Text)) Then
                lblStudentComment.Text = "Student deleted succesfully!"
                lblStudentComment.Visible = True

                AdministratorWindow.FillLabels()
            Else
                lblStudentComment.Text = "Student could not be deleted!"
                lblStudentComment.Visible = True
            End If
        End If
    End Sub

    Private Sub CommentsGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles CommentsGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = CommentsGridView.Rows(index)
        txtCommentID.Text = selectedRow.Cells(0).Value.ToString()
    End Sub

    Private Sub txtBoxInfo_TextChanged(sender As Object, e As EventArgs) Handles txtBoxInfo.TextChanged

    End Sub
End Class