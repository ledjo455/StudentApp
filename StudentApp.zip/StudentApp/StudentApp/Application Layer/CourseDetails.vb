﻿Public Class CourseDetails
    Private Sub CourseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CourseBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.UniversityMSDataSet)

    End Sub

    Private Sub CourseDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.
        'Me.CourseTableAdapter.Fill(Me.UniversityMSDataSet.Course)
        Dim query As String = "SELECT ID, TITLE From Course"
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries()
        Dim table As DataTable = con.getData(query)
        dataGridViewCourses.DataSource = table
        con.Close()

        fillTheData(1)
    End Sub

    Private Sub DataGridViewCourses_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dataGridViewCourses.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = dataGridViewCourses.Rows(index)
        Dim courseID As Integer = selectedRow.Cells(0).Value
        fillTheData(courseID)
    End Sub

    Private Sub fillTheData(ByVal courseID As Integer)
        Me.CourseTableAdapter.FillBy(Me.UniversityMSDataSet.Course, courseID)
        Dim query As String = "SELECT s.Name, s.Surname, s.Major, s.Minor
                               From StudentCourse As sc INNER Join
                               Student As s On sc.StudentID = s.ID
                               Where sc.CourseID = " & courseID
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries()
        Dim table As DataTable = con.getData(query)
        dataGridViewParticipants.DataSource = table
        con.Close()
        dataGridViewParticipants.ClearSelection()
        dataGridViewCourses.ClearSelection()
    End Sub
End Class