﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CourseDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IDLabel As System.Windows.Forms.Label
        Dim DayLabel As System.Windows.Forms.Label
        Dim TimeLabel As System.Windows.Forms.Label
        Dim InstructorLabel As System.Windows.Forms.Label
        Dim DepartmentLabel As System.Windows.Forms.Label
        Dim FacultyLabel As System.Windows.Forms.Label
        Dim CreditsLabel As System.Windows.Forms.Label
        Dim ClassLabel As System.Windows.Forms.Label
        Dim EligibilityLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CourseDetails))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dataGridViewCourses = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dataGridViewParticipants = New System.Windows.Forms.DataGridView()
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CourseTableAdapter()
        Me.TableAdapterManager = New StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager()
        Me.CourseBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CourseBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.IDLabel1 = New System.Windows.Forms.Label()
        Me.TitleLabel1 = New System.Windows.Forms.Label()
        Me.DayLabel1 = New System.Windows.Forms.Label()
        Me.TimeLabel1 = New System.Windows.Forms.Label()
        Me.InstructorLabel1 = New System.Windows.Forms.Label()
        Me.DepartmentLabel1 = New System.Windows.Forms.Label()
        Me.FacultyLabel1 = New System.Windows.Forms.Label()
        Me.CreditsLabel1 = New System.Windows.Forms.Label()
        Me.ClassLabel1 = New System.Windows.Forms.Label()
        Me.EligibilityLabel1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        IDLabel = New System.Windows.Forms.Label()
        DayLabel = New System.Windows.Forms.Label()
        TimeLabel = New System.Windows.Forms.Label()
        InstructorLabel = New System.Windows.Forms.Label()
        DepartmentLabel = New System.Windows.Forms.Label()
        FacultyLabel = New System.Windows.Forms.Label()
        CreditsLabel = New System.Windows.Forms.Label()
        ClassLabel = New System.Windows.Forms.Label()
        EligibilityLabel = New System.Windows.Forms.Label()
        CType(Me.dataGridViewCourses, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataGridViewParticipants, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CourseBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IDLabel.Location = New System.Drawing.Point(77, 416)
        IDLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(35, 24)
        IDLabel.TabIndex = 15
        IDLabel.Text = "ID:"
        '
        'DayLabel
        '
        DayLabel.AutoSize = True
        DayLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DayLabel.Location = New System.Drawing.Point(77, 469)
        DayLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DayLabel.Name = "DayLabel"
        DayLabel.Size = New System.Drawing.Size(51, 24)
        DayLabel.TabIndex = 17
        DayLabel.Text = "Day:"
        '
        'TimeLabel
        '
        TimeLabel.AutoSize = True
        TimeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TimeLabel.Location = New System.Drawing.Point(77, 527)
        TimeLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TimeLabel.Name = "TimeLabel"
        TimeLabel.Size = New System.Drawing.Size(63, 24)
        TimeLabel.TabIndex = 18
        TimeLabel.Text = "Time:"
        '
        'InstructorLabel
        '
        InstructorLabel.AutoSize = True
        InstructorLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        InstructorLabel.Location = New System.Drawing.Point(368, 416)
        InstructorLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        InstructorLabel.Name = "InstructorLabel"
        InstructorLabel.Size = New System.Drawing.Size(102, 24)
        InstructorLabel.TabIndex = 19
        InstructorLabel.Text = "Instructor:"
        '
        'DepartmentLabel
        '
        DepartmentLabel.AutoSize = True
        DepartmentLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DepartmentLabel.Location = New System.Drawing.Point(368, 468)
        DepartmentLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DepartmentLabel.Name = "DepartmentLabel"
        DepartmentLabel.Size = New System.Drawing.Size(123, 24)
        DepartmentLabel.TabIndex = 20
        DepartmentLabel.Text = "Department:"
        '
        'FacultyLabel
        '
        FacultyLabel.AutoSize = True
        FacultyLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FacultyLabel.Location = New System.Drawing.Point(368, 527)
        FacultyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FacultyLabel.Name = "FacultyLabel"
        FacultyLabel.Size = New System.Drawing.Size(83, 24)
        FacultyLabel.TabIndex = 21
        FacultyLabel.Text = "Faculty:"
        '
        'CreditsLabel
        '
        CreditsLabel.AutoSize = True
        CreditsLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CreditsLabel.Location = New System.Drawing.Point(869, 416)
        CreditsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        CreditsLabel.Name = "CreditsLabel"
        CreditsLabel.Size = New System.Drawing.Size(81, 24)
        CreditsLabel.TabIndex = 22
        CreditsLabel.Text = "Credits:"
        '
        'ClassLabel
        '
        ClassLabel.AutoSize = True
        ClassLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ClassLabel.Location = New System.Drawing.Point(869, 468)
        ClassLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        ClassLabel.Name = "ClassLabel"
        ClassLabel.Size = New System.Drawing.Size(66, 24)
        ClassLabel.TabIndex = 23
        ClassLabel.Text = "Class:"
        '
        'EligibilityLabel
        '
        EligibilityLabel.AutoSize = True
        EligibilityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EligibilityLabel.Location = New System.Drawing.Point(869, 527)
        EligibilityLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        EligibilityLabel.Name = "EligibilityLabel"
        EligibilityLabel.Size = New System.Drawing.Size(99, 24)
        EligibilityLabel.TabIndex = 24
        EligibilityLabel.Text = "Eligibility:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(228, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Click on the table"
        '
        'dataGridViewCourses
        '
        Me.dataGridViewCourses.AllowUserToAddRows = False
        Me.dataGridViewCourses.AllowUserToDeleteRows = False
        Me.dataGridViewCourses.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dataGridViewCourses.BackgroundColor = System.Drawing.Color.White
        Me.dataGridViewCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewCourses.Location = New System.Drawing.Point(275, 79)
        Me.dataGridViewCourses.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dataGridViewCourses.Name = "dataGridViewCourses"
        Me.dataGridViewCourses.ReadOnly = True
        Me.dataGridViewCourses.RowHeadersWidth = 51
        Me.dataGridViewCourses.Size = New System.Drawing.Size(588, 233)
        Me.dataGridViewCourses.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(37, 343)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(207, 31)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Course Details"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(487, 592)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(310, 32)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Course Participants"
        '
        'dataGridViewParticipants
        '
        Me.dataGridViewParticipants.AllowUserToAddRows = False
        Me.dataGridViewParticipants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dataGridViewParticipants.BackgroundColor = System.Drawing.Color.White
        Me.dataGridViewParticipants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewParticipants.Location = New System.Drawing.Point(61, 641)
        Me.dataGridViewParticipants.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dataGridViewParticipants.Name = "dataGridViewParticipants"
        Me.dataGridViewParticipants.ReadOnly = True
        Me.dataGridViewParticipants.RowHeadersWidth = 51
        Me.dataGridViewParticipants.Size = New System.Drawing.Size(1059, 185)
        Me.dataGridViewParticipants.TabIndex = 14
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        'Me.TableAdapterManager.AdministratorsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CommentTableAdapter = Nothing
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.FriendshipTableAdapter = Nothing
        Me.TableAdapterManager.StudentCourseTableAdapter = Nothing
        Me.TableAdapterManager.StudentTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CourseBindingNavigator
        '
        Me.CourseBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CourseBindingNavigator.BindingSource = Me.CourseBindingSource
        Me.CourseBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CourseBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.CourseBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.CourseBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.CourseBindingNavigatorSaveItem})
        Me.CourseBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.CourseBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CourseBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CourseBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CourseBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CourseBindingNavigator.Name = "CourseBindingNavigator"
        Me.CourseBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CourseBindingNavigator.Size = New System.Drawing.Size(1215, 31)
        Me.CourseBindingNavigator.TabIndex = 15
        Me.CourseBindingNavigator.Text = "BindingNavigator1"
        Me.CourseBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(45, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(65, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 31)
        '
        'CourseBindingNavigatorSaveItem
        '
        Me.CourseBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CourseBindingNavigatorSaveItem.Image = CType(resources.GetObject("CourseBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CourseBindingNavigatorSaveItem.Name = "CourseBindingNavigatorSaveItem"
        Me.CourseBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 28)
        Me.CourseBindingNavigatorSaveItem.Text = "Save Data"
        '
        'IDLabel1
        '
        Me.IDLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "ID", True))
        Me.IDLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDLabel1.Location = New System.Drawing.Point(152, 416)
        Me.IDLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.IDLabel1.Name = "IDLabel1"
        Me.IDLabel1.Size = New System.Drawing.Size(133, 28)
        Me.IDLabel1.TabIndex = 16
        Me.IDLabel1.Text = "Label4"
        '
        'TitleLabel1
        '
        Me.TitleLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Title", True))
        Me.TitleLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleLabel1.Location = New System.Drawing.Point(296, 343)
        Me.TitleLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.TitleLabel1.Name = "TitleLabel1"
        Me.TitleLabel1.Size = New System.Drawing.Size(408, 28)
        Me.TitleLabel1.TabIndex = 17
        Me.TitleLabel1.Text = "Label4"
        '
        'DayLabel1
        '
        Me.DayLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Day", True))
        Me.DayLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DayLabel1.Location = New System.Drawing.Point(152, 469)
        Me.DayLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.DayLabel1.Name = "DayLabel1"
        Me.DayLabel1.Size = New System.Drawing.Size(133, 28)
        Me.DayLabel1.TabIndex = 18
        Me.DayLabel1.Text = "Label4"
        '
        'TimeLabel1
        '
        Me.TimeLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Time", True))
        Me.TimeLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimeLabel1.Location = New System.Drawing.Point(152, 527)
        Me.TimeLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.TimeLabel1.Name = "TimeLabel1"
        Me.TimeLabel1.Size = New System.Drawing.Size(133, 28)
        Me.TimeLabel1.TabIndex = 19
        Me.TimeLabel1.Text = "Label4"
        '
        'InstructorLabel1
        '
        Me.InstructorLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Instructor", True))
        Me.InstructorLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InstructorLabel1.Location = New System.Drawing.Point(509, 416)
        Me.InstructorLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.InstructorLabel1.Name = "InstructorLabel1"
        Me.InstructorLabel1.Size = New System.Drawing.Size(321, 28)
        Me.InstructorLabel1.TabIndex = 20
        Me.InstructorLabel1.Text = "Label4"
        '
        'DepartmentLabel1
        '
        Me.DepartmentLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Department", True))
        Me.DepartmentLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepartmentLabel1.Location = New System.Drawing.Point(509, 469)
        Me.DepartmentLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.DepartmentLabel1.Name = "DepartmentLabel1"
        Me.DepartmentLabel1.Size = New System.Drawing.Size(353, 28)
        Me.DepartmentLabel1.TabIndex = 21
        Me.DepartmentLabel1.Text = "Label4"
        '
        'FacultyLabel1
        '
        Me.FacultyLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Faculty", True))
        Me.FacultyLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FacultyLabel1.Location = New System.Drawing.Point(509, 527)
        Me.FacultyLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.FacultyLabel1.Name = "FacultyLabel1"
        Me.FacultyLabel1.Size = New System.Drawing.Size(133, 28)
        Me.FacultyLabel1.TabIndex = 22
        Me.FacultyLabel1.Text = "Label4"
        '
        'CreditsLabel1
        '
        Me.CreditsLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Credits", True))
        Me.CreditsLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreditsLabel1.Location = New System.Drawing.Point(1003, 416)
        Me.CreditsLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.CreditsLabel1.Name = "CreditsLabel1"
        Me.CreditsLabel1.Size = New System.Drawing.Size(133, 28)
        Me.CreditsLabel1.TabIndex = 23
        Me.CreditsLabel1.Text = "Label4"
        '
        'ClassLabel1
        '
        Me.ClassLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Class", True))
        Me.ClassLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClassLabel1.Location = New System.Drawing.Point(1003, 469)
        Me.ClassLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ClassLabel1.Name = "ClassLabel1"
        Me.ClassLabel1.Size = New System.Drawing.Size(133, 28)
        Me.ClassLabel1.TabIndex = 24
        Me.ClassLabel1.Text = "Label4"
        '
        'EligibilityLabel1
        '
        Me.EligibilityLabel1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Eligibility", True))
        Me.EligibilityLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EligibilityLabel1.Location = New System.Drawing.Point(1003, 527)
        Me.EligibilityLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EligibilityLabel1.Name = "EligibilityLabel1"
        Me.EligibilityLabel1.Size = New System.Drawing.Size(133, 28)
        Me.EligibilityLabel1.TabIndex = 25
        Me.EligibilityLabel1.Text = "Label4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label4.Location = New System.Drawing.Point(507, 25)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(183, 32)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Course List"
        '
        'CourseDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.background1
        Me.ClientSize = New System.Drawing.Size(1215, 853)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(EligibilityLabel)
        Me.Controls.Add(Me.EligibilityLabel1)
        Me.Controls.Add(ClassLabel)
        Me.Controls.Add(Me.ClassLabel1)
        Me.Controls.Add(CreditsLabel)
        Me.Controls.Add(Me.CreditsLabel1)
        Me.Controls.Add(FacultyLabel)
        Me.Controls.Add(Me.FacultyLabel1)
        Me.Controls.Add(DepartmentLabel)
        Me.Controls.Add(Me.DepartmentLabel1)
        Me.Controls.Add(InstructorLabel)
        Me.Controls.Add(Me.InstructorLabel1)
        Me.Controls.Add(TimeLabel)
        Me.Controls.Add(Me.TimeLabel1)
        Me.Controls.Add(DayLabel)
        Me.Controls.Add(Me.DayLabel1)
        Me.Controls.Add(Me.TitleLabel1)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDLabel1)
        Me.Controls.Add(Me.CourseBindingNavigator)
        Me.Controls.Add(Me.dataGridViewParticipants)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dataGridViewCourses)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "CourseDetails"
        Me.Text = "Course Details"
        CType(Me.dataGridViewCourses, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataGridViewParticipants, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CourseBindingNavigator.ResumeLayout(False)
        Me.CourseBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents dataGridViewCourses As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents dataGridViewParticipants As DataGridView
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents CourseBindingSource As BindingSource
    Friend WithEvents CourseTableAdapter As UniversityMSDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents TableAdapterManager As UniversityMSDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CourseBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CourseBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents IDLabel1 As Label
    Friend WithEvents TitleLabel1 As Label
    Friend WithEvents DayLabel1 As Label
    Friend WithEvents TimeLabel1 As Label
    Friend WithEvents InstructorLabel1 As Label
    Friend WithEvents DepartmentLabel1 As Label
    Friend WithEvents FacultyLabel1 As Label
    Friend WithEvents CreditsLabel1 As Label
    Friend WithEvents ClassLabel1 As Label
    Friend WithEvents EligibilityLabel1 As Label
    Friend WithEvents Label4 As Label
End Class
