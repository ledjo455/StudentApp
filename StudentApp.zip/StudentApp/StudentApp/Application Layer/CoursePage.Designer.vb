﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CoursePage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TitleLabel As System.Windows.Forms.Label
        Dim InstructorLabel As System.Windows.Forms.Label
        Dim CreditsLabel As System.Windows.Forms.Label
        Dim DayLabel As System.Windows.Forms.Label
        Dim TimeLabel As System.Windows.Forms.Label
        Dim ClassLabel As System.Windows.Forms.Label
        Dim DepartmentLabel As System.Windows.Forms.Label
        Dim FacultyLabel As System.Windows.Forms.Label
        Dim EligibilityLabel As System.Windows.Forms.Label
        Dim IDLabel1 As System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.commentBtn = New System.Windows.Forms.Button()
        Me.txtAddComment = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.StudentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.UniversityMSDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.StudentTableAdapter()
        Me.TableAdapterManager = New StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager()
        Me.CourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CourseTableAdapter()
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.ParameterToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ParameterToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.CommentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CommentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CommentTableAdapter()
        Me.StudentCourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentCourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.StudentCourseTableAdapter()
        Me.dataGridViewParticipants = New System.Windows.Forms.DataGridView()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.IDLabel2 = New System.Windows.Forms.Label()
        Me.TitleLabel2 = New System.Windows.Forms.Label()
        Me.CommentTableAdapter1 = New StudentApp.UniversityMSDataSetTableAdapters.CommentTableAdapter()
        Me.CreditsLabel2 = New System.Windows.Forms.Label()
        Me.InstructorLabel2 = New System.Windows.Forms.Label()
        Me.ClassLabel2 = New System.Windows.Forms.Label()
        Me.DayLabel2 = New System.Windows.Forms.Label()
        Me.TimeLabel2 = New System.Windows.Forms.Label()
        Me.EligibilityLabel2 = New System.Windows.Forms.Label()
        Me.FacultyLabel2 = New System.Windows.Forms.Label()
        Me.DepartmentLabel2 = New System.Windows.Forms.Label()
        TitleLabel = New System.Windows.Forms.Label()
        InstructorLabel = New System.Windows.Forms.Label()
        CreditsLabel = New System.Windows.Forms.Label()
        DayLabel = New System.Windows.Forms.Label()
        TimeLabel = New System.Windows.Forms.Label()
        ClassLabel = New System.Windows.Forms.Label()
        DepartmentLabel = New System.Windows.Forms.Label()
        FacultyLabel = New System.Windows.Forms.Label()
        EligibilityLabel = New System.Windows.Forms.Label()
        IDLabel1 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        CType(Me.CommentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentCourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dataGridViewParticipants, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TitleLabel
        '
        TitleLabel.AutoSize = True
        TitleLabel.Font = New System.Drawing.Font("Verdana", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TitleLabel.Location = New System.Drawing.Point(235, 23)
        TitleLabel.Name = "TitleLabel"
        TitleLabel.Size = New System.Drawing.Size(157, 25)
        TitleLabel.TabIndex = 31
        TitleLabel.Text = "Welcome to "
        '
        'InstructorLabel
        '
        InstructorLabel.AutoSize = True
        InstructorLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        InstructorLabel.Location = New System.Drawing.Point(262, 186)
        InstructorLabel.Name = "InstructorLabel"
        InstructorLabel.Size = New System.Drawing.Size(92, 20)
        InstructorLabel.TabIndex = 32
        InstructorLabel.Text = "Instructor:"
        '
        'CreditsLabel
        '
        CreditsLabel.AutoSize = True
        CreditsLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CreditsLabel.Location = New System.Drawing.Point(684, 183)
        CreditsLabel.Name = "CreditsLabel"
        CreditsLabel.Size = New System.Drawing.Size(71, 20)
        CreditsLabel.TabIndex = 33
        CreditsLabel.Text = "Credits:"
        '
        'DayLabel
        '
        DayLabel.AutoSize = True
        DayLabel.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DayLabel.Location = New System.Drawing.Point(8, 243)
        DayLabel.Name = "DayLabel"
        DayLabel.Size = New System.Drawing.Size(48, 18)
        DayLabel.TabIndex = 34
        DayLabel.Text = "Day:"
        '
        'TimeLabel
        '
        TimeLabel.AutoSize = True
        TimeLabel.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TimeLabel.Location = New System.Drawing.Point(8, 295)
        TimeLabel.Name = "TimeLabel"
        TimeLabel.Size = New System.Drawing.Size(57, 18)
        TimeLabel.TabIndex = 35
        TimeLabel.Text = "Time:"
        '
        'ClassLabel
        '
        ClassLabel.AutoSize = True
        ClassLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ClassLabel.Location = New System.Drawing.Point(684, 243)
        ClassLabel.Name = "ClassLabel"
        ClassLabel.Size = New System.Drawing.Size(58, 20)
        ClassLabel.TabIndex = 36
        ClassLabel.Text = "Class:"
        '
        'DepartmentLabel
        '
        DepartmentLabel.AutoSize = True
        DepartmentLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DepartmentLabel.Location = New System.Drawing.Point(262, 243)
        DepartmentLabel.Name = "DepartmentLabel"
        DepartmentLabel.Size = New System.Drawing.Size(109, 20)
        DepartmentLabel.TabIndex = 37
        DepartmentLabel.Text = "Department:"
        '
        'FacultyLabel
        '
        FacultyLabel.AutoSize = True
        FacultyLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FacultyLabel.Location = New System.Drawing.Point(262, 298)
        FacultyLabel.Name = "FacultyLabel"
        FacultyLabel.Size = New System.Drawing.Size(72, 20)
        FacultyLabel.TabIndex = 38
        FacultyLabel.Text = "Faculty:"
        '
        'EligibilityLabel
        '
        EligibilityLabel.AutoSize = True
        EligibilityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EligibilityLabel.Location = New System.Drawing.Point(684, 295)
        EligibilityLabel.Name = "EligibilityLabel"
        EligibilityLabel.Size = New System.Drawing.Size(84, 20)
        EligibilityLabel.TabIndex = 39
        EligibilityLabel.Text = "Eligibility:"
        '
        'IDLabel1
        '
        IDLabel1.AutoSize = True
        IDLabel1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IDLabel1.Location = New System.Drawing.Point(12, 186)
        IDLabel1.Name = "IDLabel1"
        IDLabel1.Size = New System.Drawing.Size(35, 18)
        IDLabel1.TabIndex = 43
        IDLabel1.Text = "ID:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.StudentApp.My.Resources.Resources.unnamed
        Me.PictureBox1.Location = New System.Drawing.Point(15, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(177, 160)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 365)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 18)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Comments:"
        '
        'txtComments
        '
        Me.txtComments.BackColor = System.Drawing.Color.White
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(12, 406)
        Me.txtComments.Multiline = True
        Me.txtComments.Name = "txtComments"
        Me.txtComments.ReadOnly = True
        Me.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtComments.Size = New System.Drawing.Size(347, 156)
        Me.txtComments.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(663, 365)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(119, 18)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Add Comment:"
        '
        'commentBtn
        '
        Me.commentBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.commentBtn.ForeColor = System.Drawing.Color.White
        Me.commentBtn.Location = New System.Drawing.Point(817, 514)
        Me.commentBtn.Name = "commentBtn"
        Me.commentBtn.Size = New System.Drawing.Size(75, 36)
        Me.commentBtn.TabIndex = 27
        Me.commentBtn.Text = "Comment"
        Me.commentBtn.UseVisualStyleBackColor = False
        '
        'txtAddComment
        '
        Me.txtAddComment.Location = New System.Drawing.Point(666, 410)
        Me.txtAddComment.Multiline = True
        Me.txtAddComment.Name = "txtAddComment"
        Me.txtAddComment.Size = New System.Drawing.Size(226, 87)
        Me.txtAddComment.TabIndex = 28
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(429, 365)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 18)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Participants:"
        '
        'StudentBindingSource
        '
        Me.StudentBindingSource.DataMember = "Student"
        Me.StudentBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'UniversityMSDataSetBindingSource
        '
        Me.UniversityMSDataSetBindingSource.DataSource = Me.UniversityMSDataSet
        Me.UniversityMSDataSetBindingSource.Position = 0
        '
        'StudentTableAdapter
        '
        Me.StudentTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CommentTableAdapter = Nothing
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.FriendshipTableAdapter = Nothing
        Me.TableAdapterManager.StudentCourseTableAdapter = Nothing
        Me.TableAdapterManager.StudentTableAdapter = Me.StudentTableAdapter
        Me.TableAdapterManager.UpdateOrder = StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ParameterToolStripLabel, Me.ParameterToolStripTextBox, Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(924, 25)
        Me.FillByToolStrip.TabIndex = 41
        Me.FillByToolStrip.Text = "FillByToolStrip"
        Me.FillByToolStrip.Visible = False
        '
        'ParameterToolStripLabel
        '
        Me.ParameterToolStripLabel.Name = "ParameterToolStripLabel"
        Me.ParameterToolStripLabel.Size = New System.Drawing.Size(64, 22)
        Me.ParameterToolStripLabel.Text = "parameter:"
        '
        'ParameterToolStripTextBox
        '
        Me.ParameterToolStripTextBox.Name = "ParameterToolStripTextBox"
        Me.ParameterToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(39, 22)
        Me.FillByToolStripButton.Text = "FillBy"
        '
        'CommentBindingSource
        '
        Me.CommentBindingSource.DataMember = "Comment"
        Me.CommentBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'CommentTableAdapter
        '
        Me.CommentTableAdapter.ClearBeforeFill = True
        '
        'StudentCourseBindingSource
        '
        Me.StudentCourseBindingSource.DataMember = "StudentCourse"
        Me.StudentCourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'StudentCourseTableAdapter
        '
        Me.StudentCourseTableAdapter.ClearBeforeFill = True
        '
        'dataGridViewParticipants
        '
        Me.dataGridViewParticipants.AllowUserToAddRows = False
        Me.dataGridViewParticipants.AllowUserToDeleteRows = False
        Me.dataGridViewParticipants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dataGridViewParticipants.BackgroundColor = System.Drawing.Color.White
        Me.dataGridViewParticipants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridViewParticipants.Location = New System.Drawing.Point(393, 406)
        Me.dataGridViewParticipants.Name = "dataGridViewParticipants"
        Me.dataGridViewParticipants.ReadOnly = True
        Me.dataGridViewParticipants.Size = New System.Drawing.Size(243, 156)
        Me.dataGridViewParticipants.TabIndex = 42
        '
        'lblInfo
        '
        Me.lblInfo.AutoSize = True
        Me.lblInfo.Location = New System.Drawing.Point(674, 567)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(142, 13)
        Me.lblInfo.TabIndex = 43
        Me.lblInfo.Text = "Comment added succesfully!"
        Me.lblInfo.Visible = False
        '
        'IDLabel2
        '
        Me.IDLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "ID", True))
        Me.IDLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IDLabel2.Location = New System.Drawing.Point(67, 183)
        Me.IDLabel2.Name = "IDLabel2"
        Me.IDLabel2.Size = New System.Drawing.Size(64, 23)
        Me.IDLabel2.TabIndex = 44
        Me.IDLabel2.Text = "Label4"
        '
        'TitleLabel2
        '
        Me.TitleLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Title", True))
        Me.TitleLabel2.Font = New System.Drawing.Font("Verdana", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleLabel2.Location = New System.Drawing.Point(216, 66)
        Me.TitleLabel2.Name = "TitleLabel2"
        Me.TitleLabel2.Size = New System.Drawing.Size(565, 46)
        Me.TitleLabel2.TabIndex = 45
        Me.TitleLabel2.Text = "Label4"
        Me.TitleLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommentTableAdapter1
        '
        Me.CommentTableAdapter1.ClearBeforeFill = True
        '
        'CreditsLabel2
        '
        Me.CreditsLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Credits", True))
        Me.CreditsLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreditsLabel2.Location = New System.Drawing.Point(782, 180)
        Me.CreditsLabel2.Name = "CreditsLabel2"
        Me.CreditsLabel2.Size = New System.Drawing.Size(100, 23)
        Me.CreditsLabel2.TabIndex = 46
        Me.CreditsLabel2.Text = "Label4"
        '
        'InstructorLabel2
        '
        Me.InstructorLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Instructor", True))
        Me.InstructorLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InstructorLabel2.Location = New System.Drawing.Point(372, 186)
        Me.InstructorLabel2.Name = "InstructorLabel2"
        Me.InstructorLabel2.Size = New System.Drawing.Size(276, 23)
        Me.InstructorLabel2.TabIndex = 47
        Me.InstructorLabel2.Text = "Label4"
        '
        'ClassLabel2
        '
        Me.ClassLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Class", True))
        Me.ClassLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClassLabel2.Location = New System.Drawing.Point(782, 243)
        Me.ClassLabel2.Name = "ClassLabel2"
        Me.ClassLabel2.Size = New System.Drawing.Size(100, 23)
        Me.ClassLabel2.TabIndex = 48
        Me.ClassLabel2.Text = "Label4"
        '
        'DayLabel2
        '
        Me.DayLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Day", True))
        Me.DayLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DayLabel2.Location = New System.Drawing.Point(67, 243)
        Me.DayLabel2.Name = "DayLabel2"
        Me.DayLabel2.Size = New System.Drawing.Size(100, 23)
        Me.DayLabel2.TabIndex = 49
        Me.DayLabel2.Text = "Label4"
        '
        'TimeLabel2
        '
        Me.TimeLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Time", True))
        Me.TimeLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimeLabel2.Location = New System.Drawing.Point(67, 295)
        Me.TimeLabel2.Name = "TimeLabel2"
        Me.TimeLabel2.Size = New System.Drawing.Size(154, 23)
        Me.TimeLabel2.TabIndex = 50
        Me.TimeLabel2.Text = "Label4"
        '
        'EligibilityLabel2
        '
        Me.EligibilityLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Eligibility", True))
        Me.EligibilityLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EligibilityLabel2.Location = New System.Drawing.Point(782, 298)
        Me.EligibilityLabel2.Name = "EligibilityLabel2"
        Me.EligibilityLabel2.Size = New System.Drawing.Size(100, 23)
        Me.EligibilityLabel2.TabIndex = 51
        Me.EligibilityLabel2.Text = "Label4"
        '
        'FacultyLabel2
        '
        Me.FacultyLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Faculty", True))
        Me.FacultyLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FacultyLabel2.Location = New System.Drawing.Point(377, 295)
        Me.FacultyLabel2.Name = "FacultyLabel2"
        Me.FacultyLabel2.Size = New System.Drawing.Size(271, 23)
        Me.FacultyLabel2.TabIndex = 52
        Me.FacultyLabel2.Text = "Label4"
        '
        'DepartmentLabel2
        '
        Me.DepartmentLabel2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Department", True))
        Me.DepartmentLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepartmentLabel2.Location = New System.Drawing.Point(377, 243)
        Me.DepartmentLabel2.Name = "DepartmentLabel2"
        Me.DepartmentLabel2.Size = New System.Drawing.Size(100, 23)
        Me.DepartmentLabel2.TabIndex = 53
        Me.DepartmentLabel2.Text = "Label4"
        '
        'CoursePage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(924, 638)
        Me.Controls.Add(Me.DepartmentLabel2)
        Me.Controls.Add(Me.FacultyLabel2)
        Me.Controls.Add(Me.EligibilityLabel2)
        Me.Controls.Add(Me.TimeLabel2)
        Me.Controls.Add(Me.DayLabel2)
        Me.Controls.Add(Me.ClassLabel2)
        Me.Controls.Add(Me.InstructorLabel2)
        Me.Controls.Add(Me.CreditsLabel2)
        Me.Controls.Add(Me.TitleLabel2)
        Me.Controls.Add(IDLabel1)
        Me.Controls.Add(Me.IDLabel2)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.dataGridViewParticipants)
        Me.Controls.Add(EligibilityLabel)
        Me.Controls.Add(FacultyLabel)
        Me.Controls.Add(DepartmentLabel)
        Me.Controls.Add(ClassLabel)
        Me.Controls.Add(TimeLabel)
        Me.Controls.Add(DayLabel)
        Me.Controls.Add(CreditsLabel)
        Me.Controls.Add(InstructorLabel)
        Me.Controls.Add(TitleLabel)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtAddComment)
        Me.Controls.Add(Me.commentBtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Name = "CoursePage"
        Me.Text = "CoursePage"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        CType(Me.CommentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentCourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dataGridViewParticipants, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtComments As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents commentBtn As Button
    Friend WithEvents txtAddComment As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents UniversityMSDataSetBindingSource As BindingSource
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents StudentBindingSource As BindingSource
    Friend WithEvents StudentTableAdapter As UniversityMSDataSetTableAdapters.StudentTableAdapter
    Friend WithEvents TableAdapterManager As UniversityMSDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CourseTableAdapter As UniversityMSDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents CourseBindingSource As BindingSource
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents ParameterToolStripLabel As ToolStripLabel
    Friend WithEvents ParameterToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents CommentBindingSource As BindingSource
    Friend WithEvents CommentTableAdapter As UniversityMSDataSetTableAdapters.CommentTableAdapter
    Friend WithEvents StudentCourseBindingSource As BindingSource
    Friend WithEvents StudentCourseTableAdapter As UniversityMSDataSetTableAdapters.StudentCourseTableAdapter
    Friend WithEvents dataGridViewParticipants As DataGridView
    Friend WithEvents lblInfo As Label
    Friend WithEvents IDLabel2 As Label
    Friend WithEvents TitleLabel2 As Label
    Friend WithEvents CommentTableAdapter1 As UniversityMSDataSetTableAdapters.CommentTableAdapter
    Friend WithEvents CreditsLabel2 As Label
    Friend WithEvents InstructorLabel2 As Label
    Friend WithEvents ClassLabel2 As Label
    Friend WithEvents DayLabel2 As Label
    Friend WithEvents TimeLabel2 As Label
    Friend WithEvents EligibilityLabel2 As Label
    Friend WithEvents FacultyLabel2 As Label
    Friend WithEvents DepartmentLabel2 As Label
End Class
