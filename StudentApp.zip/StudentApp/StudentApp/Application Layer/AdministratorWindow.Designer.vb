﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdministratorWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblStudents = New System.Windows.Forms.Label()
        Me.lblCourses = New System.Windows.Forms.Label()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnSeeCourse = New System.Windows.Forms.Button()
        Me.btnSeeStudents = New System.Windows.Forms.Button()
        Me.btnAddCourse = New System.Windows.Forms.Button()
        Me.btnAddStudent = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblLogout = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.lblStudents)
        Me.GroupBox1.Controls.Add(Me.lblCourses)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(384, 140)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Application Data"
        '
        'lblStudents
        '
        Me.lblStudents.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudents.Location = New System.Drawing.Point(8, 53)
        Me.lblStudents.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStudents.Name = "lblStudents"
        Me.lblStudents.Size = New System.Drawing.Size(333, 22)
        Me.lblStudents.TabIndex = 1
        Me.lblStudents.Text = "Total  number of students:"
        Me.lblStudents.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblCourses
        '
        Me.lblCourses.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourses.Location = New System.Drawing.Point(8, 31)
        Me.lblCourses.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCourses.Name = "lblCourses"
        Me.lblCourses.Size = New System.Drawing.Size(321, 22)
        Me.lblCourses.TabIndex = 0
        Me.lblCourses.Text = "Total number of courses:"
        Me.lblCourses.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblWelcome
        '
        Me.lblWelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblWelcome.Font = New System.Drawing.Font("Ink Free", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.Location = New System.Drawing.Point(450, 64)
        Me.lblWelcome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(335, 89)
        Me.lblWelcome.TabIndex = 1
        Me.lblWelcome.Text = "     Welcome " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Name Surname"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.btnSeeCourse)
        Me.GroupBox2.Controls.Add(Me.btnSeeStudents)
        Me.GroupBox2.Controls.Add(Me.btnAddCourse)
        Me.GroupBox2.Controls.Add(Me.btnAddStudent)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(643, 271)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(494, 469)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.BurlyWood
        Me.Button2.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(261, 244)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(193, 69)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "See Friendships"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.BurlyWood
        Me.Button1.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(29, 244)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(193, 69)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "See Comments"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'btnSeeCourse
        '
        Me.btnSeeCourse.BackColor = System.Drawing.Color.BurlyWood
        Me.btnSeeCourse.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnSeeCourse.ForeColor = System.Drawing.Color.Black
        Me.btnSeeCourse.Location = New System.Drawing.Point(261, 142)
        Me.btnSeeCourse.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSeeCourse.Name = "btnSeeCourse"
        Me.btnSeeCourse.Size = New System.Drawing.Size(193, 69)
        Me.btnSeeCourse.TabIndex = 5
        Me.btnSeeCourse.Text = " See Courses"
        Me.btnSeeCourse.UseVisualStyleBackColor = False
        '
        'btnSeeStudents
        '
        Me.btnSeeStudents.BackColor = System.Drawing.Color.BurlyWood
        Me.btnSeeStudents.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnSeeStudents.ForeColor = System.Drawing.Color.Black
        Me.btnSeeStudents.Location = New System.Drawing.Point(29, 142)
        Me.btnSeeStudents.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSeeStudents.Name = "btnSeeStudents"
        Me.btnSeeStudents.Size = New System.Drawing.Size(193, 69)
        Me.btnSeeStudents.TabIndex = 4
        Me.btnSeeStudents.Text = "See Students"
        Me.btnSeeStudents.UseVisualStyleBackColor = False
        '
        'btnAddCourse
        '
        Me.btnAddCourse.BackColor = System.Drawing.Color.BurlyWood
        Me.btnAddCourse.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnAddCourse.ForeColor = System.Drawing.Color.Black
        Me.btnAddCourse.Location = New System.Drawing.Point(261, 46)
        Me.btnAddCourse.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAddCourse.Name = "btnAddCourse"
        Me.btnAddCourse.Size = New System.Drawing.Size(193, 65)
        Me.btnAddCourse.TabIndex = 2
        Me.btnAddCourse.Text = "Add Course"
        Me.btnAddCourse.UseVisualStyleBackColor = False
        '
        'btnAddStudent
        '
        Me.btnAddStudent.BackColor = System.Drawing.Color.BurlyWood
        Me.btnAddStudent.Font = New System.Drawing.Font("Ink Free", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnAddStudent.ForeColor = System.Drawing.Color.Black
        Me.btnAddStudent.Location = New System.Drawing.Point(29, 46)
        Me.btnAddStudent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAddStudent.Name = "btnAddStudent"
        Me.btnAddStudent.Size = New System.Drawing.Size(193, 65)
        Me.btnAddStudent.TabIndex = 0
        Me.btnAddStudent.Text = "Add Student"
        Me.btnAddStudent.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.StudentApp.My.Resources.Resources.logout
        Me.PictureBox1.Location = New System.Drawing.Point(1460, 507)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(269, 279)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'lblLogout
        '
        Me.lblLogout.AutoSize = True
        Me.lblLogout.BackColor = System.Drawing.Color.Transparent
        Me.lblLogout.Font = New System.Drawing.Font("Arial Black", 25.0!)
        Me.lblLogout.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.lblLogout.Location = New System.Drawing.Point(1486, 798)
        Me.lblLogout.Name = "lblLogout"
        Me.lblLogout.Size = New System.Drawing.Size(205, 59)
        Me.lblLogout.TabIndex = 6
        Me.lblLogout.Text = "Log Out"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Ink Free", 16.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(7, 157)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(433, 89)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Current Time"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = Global.StudentApp.My.Resources.Resources.Operations__1_
        Me.PictureBox2.Location = New System.Drawing.Point(659, 157)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(459, 119)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = Global.StudentApp.My.Resources.Resources.operations
        Me.PictureBox3.Location = New System.Drawing.Point(1051, 167)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(141, 119)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 10
        Me.PictureBox3.TabStop = False
        '
        'AdministratorWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.yale
        Me.ClientSize = New System.Drawing.Size(1902, 1033)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblLogout)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "AdministratorWindow"
        Me.Text = "Admininstrator"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblStudents As Label
    Friend WithEvents lblCourses As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnAddCourse As Button
    Friend WithEvents btnAddStudent As Button
    Friend WithEvents btnSeeCourse As Button
    Friend WithEvents btnSeeStudents As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblLogout As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
End Class
