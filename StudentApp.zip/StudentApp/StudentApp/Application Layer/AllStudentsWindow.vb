﻿Public Class AllStudentsWindow
    Private Sub AllStudentsWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillTheTable()
    End Sub

    Private Sub fillTheTable()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select ID, NAME, SURNAME, MAJOR, MINOR from student"
        Dim table As DataTable = con.getData(query)

        allStudentsDataGridView.DataSource = table
        allStudentsDataGridView.ClearSelection()
    End Sub

    Private Function existsFriendship(ByVal userID As Integer, ByVal friendID As Integer) As Boolean
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from friendship where studentid=" & userID & "and friendid=" & friendID
        Dim table As DataTable = con.getData(query)
        If table.Rows.Count = 0 Then
            con.Close()
            Return False
        Else
            con.Close()
            Return True
        End If

    End Function

    Private Sub AllStudentsDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles allStudentsDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = allStudentsDataGridView.Rows(index)
        lblStudentID.Text = selectedRow.Cells(0).Value.ToString()

    End Sub

    Private Sub DisplayBtn_Click(sender As Object, e As EventArgs) Handles displayBtn.Click
        fillTheTable()
    End Sub

    Private Sub AddBtn_Click(sender As Object, e As EventArgs) Handles addBtn.Click
        If lblStudentID.Text = "" Then 'check if user has clicked the gridview
            MessageBox.Show("Please enter an ID or click the table! ", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim friendID As Integer = Integer.Parse(lblStudentID.Text)
            'MessageBox.Show(existsFriendship(MainWindow.userID, friendID))
            If existsFriendship(MainWindow.userID, friendID) Then 'check if friendship already exists
                MessageBox.Show("This student is already on your friends' list! ", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If MainWindow.userID = friendID Then 'check if user is trying to add friendship with himself
                    MessageBox.Show("You cannot add friendship with yourself! ", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else 'add friendship
                    addFriendship(MainWindow.userID, friendID)
                End If
            End If
        End If
    End Sub

    Private Sub addFriendship(userID As Integer, friendID As Integer)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "INSERT INTO friendship (StudentID, FriendID) VALUES (" & userID & ", " & friendID & ");"
        If con.addOrDeleteData(query) Then
            MessageBox.Show("Friend added succesfully!", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Database error! Cannot add friend! ", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub SearchBtn_Click(sender As Object, e As EventArgs) Handles searchBtn.Click
        If txtStudentName.Text = "" Then
            MessageBox.Show("Enter a name!", "Search Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            searchByName(txtStudentName.Text)

        End If
    End Sub

    Private Sub searchByName(name As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select ID, NAME, SURNAME, MAJOR, MINOR from student where name='" & name & "';"
        Dim table As DataTable = con.getData(query)
        If table.Rows.Count > 0 Then
            allStudentsDataGridView.DataSource = table
            allStudentsDataGridView.ClearSelection()
        Else
            MessageBox.Show("No students with this name!", "Add Friend", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class