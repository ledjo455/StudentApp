﻿Public Class SearchCourse
    Private Sub SearchCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillTheTables()
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.



    End Sub

    Private Sub fillTheTables()

        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "SELECT DISTINCT c.ID, c.Title, c.Instructor, c.Credits, c.Day, c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
From Course As c INNER Join
                         StudentCourse As sc On c.ID = sc.CourseID INNER Join
                         Student As s On sc.StudentID = s.ID
Where (c.Eligibility = 'All') OR
                         (c.Department = '" & MainWindow.user.MajorProperty & "') Or
                         (c.Department = '" & MainWindow.user.MinorProperty & "')"
        Dim table As DataTable = con.getData(query)
        CourseListDataGridView.DataSource = table
        Me.CourseTableAdapter.DisplayCoursesOfUser(Me.UniversityMSDataSet.Course, MainWindow.userID)

        Dim query2 As String = "SELECT c.ID, c.Title, c.Instructor, c.Credits, c.Day, c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
FROM  Course AS c INNER JOIN
                         StudentCourse AS sc ON c.ID = sc.CourseID
WHERE        (sc.StudentID =" & MainWindow.userID & ")"
        Dim table2 As DataTable = con.getData(query2)
        CourseDataGridView.DataSource = table2
        con.Close()
        CourseDataGridView.ClearSelection()
        CourseListDataGridView.ClearSelection()
        txtAddCourse.Text = ""
        txtDropCourse.Text = ""
    End Sub

    Private Sub FillAllPossibilitiesToolStripButton_Click(sender As Object, e As EventArgs) Handles FillAllPossibilitiesToolStripButton.Click
        Try
            Me.CourseTableAdapter.FillAllPossibilities(Me.UniversityMSDataSet.Course, Parameter1ToolStripTextBox.Text, Parameter2ToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub AddBtn_Click(sender As Object, e As EventArgs) Handles addBtn.Click
        Dim courseID As Integer
        If Integer.TryParse(txtAddCourse.Text, courseID) Then
            'check if the user has already the course
            Dim query As String = "SELECT c.ID, c.Title, c.Instructor, c.Credits, c.Day, c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
From Course As c INNER Join
                         StudentCourse As sc On c.ID = sc.CourseID INNER Join
                         Student As s On sc.StudentID = s.ID
Where (s.ID =" & MainWindow.userID & ") AND
                         (c.ID = " & courseID & ")"
            Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            Dim table As DataTable = con.getData(query)
            Dim isFound As Boolean = False
            For index = 0 To table.Rows.Count - 1
                If table.Rows.Item(index).Item(0) = courseID Then
                    'the user has the course he/she is trying to add
                    MessageBox.Show("This course cannot be added because it is already on your course list!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    isFound = True
                    Exit For
                End If
            Next index
            'add the course
            If Not isFound Then

                Dim insertQuery As String = "INSERT INTO studentcourse (StudentID, CourseID) VALUES (" & MainWindow.userID & ", " & courseID & ");"
                If con.addOrDeleteData(insertQuery) Then 'data added succesfully
                    MessageBox.Show("Course added succesfully! Check MyCourseList below or refresh the table in the main window!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    fillTheTables()
                End If
            End If

            con.Close()
        Else
            MessageBox.Show("Wrong Course ID! Enter again or select from the table!", "Add Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    Private Sub DropBtn_Click(sender As Object, e As EventArgs) Handles dropBtn.Click
        Dim courseID As Integer
        If Integer.TryParse(txtDropCourse.Text, courseID) Then
            'check if the user has the course
            Dim query As String = "SELECT c.ID, c.Title, c.Instructor, c.Credits, c.Day, c.Time, c.Class, c.Department, c.Faculty, c.Eligibility
FROM            Course AS c INNER JOIN
                         StudentCourse AS sc ON c.ID = sc.CourseID
WHERE        (sc.StudentID =" & MainWindow.userID & ") and (c.ID =" & courseID & ")"
            Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            Dim table As DataTable = con.getData(query)
            If table.Rows.Count = 1 Then
                'drop the course
                Dim delQuery As String = "DELETE FROM studentcourse " &
                 "WHERE StudentID =" & MainWindow.userID & "And CourseID = " & courseID
                If con.addOrDeleteData(delQuery) Then
                    con.Close()
                    MessageBox.Show("Course Dropped Succesfully!Check MyCourseList Table or refresh the table in the main widnow!", "Drop Course", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    fillTheTables()
                End If
            Else
                    'course not in the course list
                    MessageBox.Show("Wrong Course ID! Enter again or select from MyCourseList Table!", "Drop Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            'ID is not numeric
            MessageBox.Show("Wrong Course ID! Enter again or select from MyCourseList Table!", "Drop Course", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub

    Private Sub CourseDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles CourseDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = CourseDataGridView.Rows(index)
        txtDropCourse.Text = selectedRow.Cells(0).Value.ToString()
    End Sub

    Private Sub CourseListDataGridView_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles CourseListDataGridView.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = CourseListDataGridView.Rows(index)
        txtAddCourse.Text = selectedRow.Cells(0).Value.ToString()

    End Sub

    Private Sub CourseListDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles CourseListDataGridView.CellContentClick

    End Sub
End Class