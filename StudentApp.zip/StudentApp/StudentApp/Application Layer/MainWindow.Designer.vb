﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.searchBtn = New System.Windows.Forms.Button()
        Me.detailsBtn = New System.Windows.Forms.Button()
        Me.allStudentsBtn = New System.Windows.Forms.Button()
        Me.friendsBtn = New System.Windows.Forms.Button()
        Me.logoutBtn = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.refreshBtn = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtCourseID = New System.Windows.Forms.TextBox()
        Me.btnCourse = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.StudentIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.StudentIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.DisplayCoursesOfUserToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.DisplayCoursesOfUserToolStrip = New System.Windows.Forms.ToolStrip()
        Me.CourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CourseTableAdapter()
        Me.TableAdapterManager = New StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.CourseDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DisplayCoursesOfUserToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.Location = New System.Drawing.Point(505, 48)
        Me.lblWelcome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(182, 50)
        Me.lblWelcome.TabIndex = 0
        Me.lblWelcome.Text = "Welcome " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Name Surname" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'searchBtn
        '
        Me.searchBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.searchBtn.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchBtn.ForeColor = System.Drawing.Color.White
        Me.searchBtn.Location = New System.Drawing.Point(279, 140)
        Me.searchBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.searchBtn.Name = "searchBtn"
        Me.searchBtn.Size = New System.Drawing.Size(253, 58)
        Me.searchBtn.TabIndex = 1
        Me.searchBtn.Text = "Search Available Courses"
        Me.searchBtn.UseVisualStyleBackColor = False
        '
        'detailsBtn
        '
        Me.detailsBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.detailsBtn.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.detailsBtn.ForeColor = System.Drawing.Color.White
        Me.detailsBtn.Location = New System.Drawing.Point(279, 220)
        Me.detailsBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.detailsBtn.Name = "detailsBtn"
        Me.detailsBtn.Size = New System.Drawing.Size(253, 54)
        Me.detailsBtn.TabIndex = 2
        Me.detailsBtn.Text = "Check Course Details"
        Me.detailsBtn.UseVisualStyleBackColor = False
        '
        'allStudentsBtn
        '
        Me.allStudentsBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.allStudentsBtn.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.allStudentsBtn.ForeColor = System.Drawing.Color.White
        Me.allStudentsBtn.Location = New System.Drawing.Point(676, 140)
        Me.allStudentsBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.allStudentsBtn.Name = "allStudentsBtn"
        Me.allStudentsBtn.Size = New System.Drawing.Size(228, 53)
        Me.allStudentsBtn.TabIndex = 3
        Me.allStudentsBtn.Text = "See All Students"
        Me.allStudentsBtn.UseVisualStyleBackColor = False
        '
        'friendsBtn
        '
        Me.friendsBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.friendsBtn.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.friendsBtn.ForeColor = System.Drawing.Color.White
        Me.friendsBtn.Location = New System.Drawing.Point(676, 220)
        Me.friendsBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.friendsBtn.Name = "friendsBtn"
        Me.friendsBtn.Size = New System.Drawing.Size(228, 53)
        Me.friendsBtn.TabIndex = 4
        Me.friendsBtn.Text = "See My Friends"
        Me.friendsBtn.UseVisualStyleBackColor = False
        '
        'logoutBtn
        '
        Me.logoutBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.logoutBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logoutBtn.ForeColor = System.Drawing.Color.White
        Me.logoutBtn.Location = New System.Drawing.Point(1187, 33)
        Me.logoutBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.logoutBtn.Name = "logoutBtn"
        Me.logoutBtn.Size = New System.Drawing.Size(141, 53)
        Me.logoutBtn.TabIndex = 6
        Me.logoutBtn.Text = "LOGOUT"
        Me.logoutBtn.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(55, 326)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 29)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "My Course List"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'refreshBtn
        '
        Me.refreshBtn.Location = New System.Drawing.Point(1187, 341)
        Me.refreshBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.refreshBtn.Name = "refreshBtn"
        Me.refreshBtn.Size = New System.Drawing.Size(143, 28)
        Me.refreshBtn.TabIndex = 8
        Me.refreshBtn.Text = "Refresh Table"
        Me.refreshBtn.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 592)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(167, 20)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Enter Course ID:"
        '
        'txtCourseID
        '
        Me.txtCourseID.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCourseID.Location = New System.Drawing.Point(212, 581)
        Me.txtCourseID.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCourseID.Name = "txtCourseID"
        Me.txtCourseID.Size = New System.Drawing.Size(172, 34)
        Me.txtCourseID.TabIndex = 11
        '
        'btnCourse
        '
        Me.btnCourse.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnCourse.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCourse.ForeColor = System.Drawing.Color.White
        Me.btnCourse.Location = New System.Drawing.Point(453, 574)
        Me.btnCourse.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCourse.Name = "btnCourse"
        Me.btnCourse.Size = New System.Drawing.Size(132, 57)
        Me.btnCourse.TabIndex = 12
        Me.btnCourse.Text = "Go to course page"
        Me.btnCourse.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(305, 336)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(360, 17)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Please refresh the table after you add or drop a course."
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1360, 28)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(55, 24)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'CourseDataGridView
        '
        Me.CourseDataGridView.AllowUserToAddRows = False
        Me.CourseDataGridView.AllowUserToDeleteRows = False
        Me.CourseDataGridView.AutoGenerateColumns = False
        Me.CourseDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.CourseDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.CourseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CourseDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.CourseDataGridView.DataSource = Me.CourseBindingSource
        Me.CourseDataGridView.Location = New System.Drawing.Point(16, 377)
        Me.CourseDataGridView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CourseDataGridView.Name = "CourseDataGridView"
        Me.CourseDataGridView.ReadOnly = True
        Me.CourseDataGridView.RowHeadersWidth = 51
        Me.CourseDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.CourseDataGridView.Size = New System.Drawing.Size(1312, 180)
        Me.CourseDataGridView.TabIndex = 17
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 60
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Title"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Title"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Instructor"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Instructor"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Credits"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Credits"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Day"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Day"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Time"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Time"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Class"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Class"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StudentIDToolStripLabel
        '
        Me.StudentIDToolStripLabel.Name = "StudentIDToolStripLabel"
        Me.StudentIDToolStripLabel.Size = New System.Drawing.Size(76, 28)
        Me.StudentIDToolStripLabel.Text = "studentID:"
        '
        'StudentIDToolStripTextBox
        '
        Me.StudentIDToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.StudentIDToolStripTextBox.Name = "StudentIDToolStripTextBox"
        Me.StudentIDToolStripTextBox.Size = New System.Drawing.Size(132, 31)
        '
        'DisplayCoursesOfUserToolStripButton
        '
        Me.DisplayCoursesOfUserToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.DisplayCoursesOfUserToolStripButton.Name = "DisplayCoursesOfUserToolStripButton"
        Me.DisplayCoursesOfUserToolStripButton.Size = New System.Drawing.Size(158, 28)
        Me.DisplayCoursesOfUserToolStripButton.Text = "DisplayCoursesOfUser"
        '
        'DisplayCoursesOfUserToolStrip
        '
        Me.DisplayCoursesOfUserToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.DisplayCoursesOfUserToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentIDToolStripLabel, Me.StudentIDToolStripTextBox, Me.DisplayCoursesOfUserToolStripButton})
        Me.DisplayCoursesOfUserToolStrip.Location = New System.Drawing.Point(0, 30)
        Me.DisplayCoursesOfUserToolStrip.Name = "DisplayCoursesOfUserToolStrip"
        Me.DisplayCoursesOfUserToolStrip.Size = New System.Drawing.Size(1416, 31)
        Me.DisplayCoursesOfUserToolStrip.TabIndex = 18
        Me.DisplayCoursesOfUserToolStrip.Text = "DisplayCoursesOfUserToolStrip"
        Me.DisplayCoursesOfUserToolStrip.Visible = False
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        'Me.TableAdapterManager.AdministratorsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CommentTableAdapter = Nothing
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.FriendshipTableAdapter = Nothing
        Me.TableAdapterManager.StudentCourseTableAdapter = Nothing
        Me.TableAdapterManager.StudentTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'MainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.yale
        Me.ClientSize = New System.Drawing.Size(1360, 661)
        Me.Controls.Add(Me.DisplayCoursesOfUserToolStrip)
        Me.Controls.Add(Me.CourseDataGridView)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnCourse)
        Me.Controls.Add(Me.txtCourseID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.refreshBtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.logoutBtn)
        Me.Controls.Add(Me.friendsBtn)
        Me.Controls.Add(Me.allStudentsBtn)
        Me.Controls.Add(Me.detailsBtn)
        Me.Controls.Add(Me.searchBtn)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "MainWindow"
        Me.Text = "MainWindow"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.CourseDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DisplayCoursesOfUserToolStrip.ResumeLayout(False)
        Me.DisplayCoursesOfUserToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblWelcome As Label
    Friend WithEvents searchBtn As Button
    Friend WithEvents detailsBtn As Button
    Friend WithEvents allStudentsBtn As Button
    Friend WithEvents friendsBtn As Button
    Friend WithEvents logoutBtn As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents refreshBtn As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents txtCourseID As TextBox
    Friend WithEvents btnCourse As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents CourseBindingSource As BindingSource
    Friend WithEvents CourseTableAdapter As UniversityMSDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents TableAdapterManager As UniversityMSDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CourseDataGridView As DataGridView
    Friend WithEvents StudentIDToolStripLabel As ToolStripLabel
    Friend WithEvents StudentIDToolStripTextBox As ToolStripTextBox
    Friend WithEvents DisplayCoursesOfUserToolStripButton As ToolStripButton
    Friend WithEvents DisplayCoursesOfUserToolStrip As ToolStrip
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
End Class
