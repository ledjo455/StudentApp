﻿Public Class AdminCourse
    Private Sub AdminCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'UniversityMSDataSet.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.UniversityMSDataSet.Course)
        fillGridView()

    End Sub

    Private Sub BtnDisplayAll_Click(sender As Object, e As EventArgs) Handles btnDisplayAll.Click
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course"
        Dim dt As DataTable = con.getData(query)

        DataGridViewCourses.DataSource = dt

    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        If txtInstructorSearch.Text <> String.Empty And txtTitleSearch.Text <> String.Empty Then
            displayDataSearchByTitleOrInstructor(txtTitleSearch.Text, txtInstructorSearch.Text)
        ElseIf (txtTitleSearch.Text <> String.Empty) Then
            displayDataSearchByTitle(txtTitleSearch.Text)
        ElseIf (txtInstructorSearch.Text <> String.Empty) Then
            displayDataSearchByInstructor(txtInstructorSearch.Text)
        End If




    End Sub

    Private Sub displayDataSearchByInstructor(inst As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course where instructor like '" & inst & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewCourses.DataSource = dt
    End Sub


    Private Sub displayDataSearchByTitle(title As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course where title like '" & title & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewCourses.DataSource = dt
    End Sub

    Private Sub displayDataSearchByTitleOrInstructor(title As String, inst As String)
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course where title like '" & title & "%' or instructor like '" & inst & "%' "
        Dim dt As DataTable = con.getData(query)

        DataGridViewCourses.DataSource = dt
    End Sub

    Private Sub DataGridViewCourses_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridViewCourses.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DataGridViewCourses.Rows(index)
        txtCourseID.Text = selectedRow.Cells(0).Value.ToString()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtCourseID.Text <> String.Empty Then
            'Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            'Dim query As String = "delete from course where id=" & Integer.Parse(txtCourseID.Text)
            Dim answer As DialogResult = MessageBox.Show("Are you sure about deleting this course?", "Delete course", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = DialogResult.Yes Then
                If Course.DeleteCourse(Integer.Parse(txtCourseID.Text)) Then
                    lblInfo.Text = "Course deleted succesfully!"
                    lblInfo.Visible = True
                    AdministratorWindow.FillLabels()
                Else
                    lblInfo.Text = "Course could not be deleted!"
                    lblInfo.Visible = True
                End If
            End If
        End If

    End Sub

    Private Sub fillGridView()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "select * from course"
        Dim dt As DataTable = con.getData(query)

        DataGridViewCourses.DataSource = dt
    End Sub
End Class