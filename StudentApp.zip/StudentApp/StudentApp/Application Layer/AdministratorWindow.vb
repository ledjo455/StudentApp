﻿Public Class AdministratorWindow
    Dim user As Administrator
    Private Sub AdministratorWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblWelcome.Text = "Welcome" & ControlChars.NewLine & user.NameProperty & "  " & user.SurnameProperty
        Label2.Text = "Current Time: " & Now.ToLongTimeString

        FillLabels()
    End Sub

    Public Sub FillLabels()
        Dim student As Student = New Student(1000, "Anna", "Frank", 22, "CS", "-", "pwd")
        Dim course As Course = New Course(11, "VB", "Albert White", 4, "Friday", "09:00-12:00", "LAB 3", "Informatics", "Computer Science", "-")

        'demonstrating polymorhpic behaviour
        Dim noOfStudents = GetNumber(student)
        Dim noOfCourses = GetNumber(course)

        lblCourses.Text = "Total number of courses:"
        lblCourses.Text = lblCourses.Text & "   " & noOfCourses & "  courses"
        lblStudents.Text = "Total number of students:"
        lblStudents.Text = lblStudents.Text & "   " & noOfStudents & "  students"
    End Sub
    Private Function GetNumber(el As ICounter) As Integer
        Return el.GetNumber()
    End Function

    Public Sub SetUser(admin As Administrator)
        user = admin
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Private Sub BtnSeeStudents_Click(sender As Object, e As EventArgs) Handles btnSeeStudents.Click
        AdminSearchAndDeleteStudent.Show()
    End Sub

    Private Sub BtnSeeCourse_Click(sender As Object, e As EventArgs) Handles btnSeeCourse.Click
        AdminCourse.Show()
    End Sub

    Private Sub BtnAddCourse_Click(sender As Object, e As EventArgs) Handles btnAddCourse.Click
        AdminAddCourse.Show()
    End Sub

    Private Sub BtnAddStudent_Click(sender As Object, e As EventArgs) Handles btnAddStudent.Click
        AdminAddStudent.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Search_And_Delete_Comment.Show()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AdminDeleteFriendship.Show()
    End Sub

    Private Sub Chart1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        LogIn.Show()
    End Sub
End Class