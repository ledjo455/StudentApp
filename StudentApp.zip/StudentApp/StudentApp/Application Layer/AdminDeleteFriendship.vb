﻿Public Class AdminDeleteFriendship
    Private Sub AdminDeleteFriendship_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillGridView()
    End Sub

    Private Sub fillGridView()
        Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
        Dim query As String = "SELECT Student.Name, Friendship.StudentID, Friendship.FriendID FROM Friendship INNER JOIN
                  Student ON Student.ID = Friendship.StudentID"
        Dim dt As DataTable = con.getData(query)

        DataGridFriend.DataSource = dt

    End Sub



    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If txtFriendship.Text <> String.Empty Then
            'Dim con As DatabaseConnectionAndQueries = New DatabaseConnectionAndQueries
            'Dim query As String = "delete from student where id=" & Integer.Parse(txtStudentID.Text)
            If Student.DeleteFriendship(Integer.Parse(txtFriendship.Text))  Then
                lblinfo.Text = "Student Friendship deleted succesfully!"
                lblinfo.Visible = True

                AdministratorWindow.FillLabels()
            Else
                lblinfo.Text = "Student's friendship could not be deleted!"
                lblinfo.Visible = True
            End If
        End If
    End Sub

    Private Sub DataGridFriend_RowHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridFriend.RowHeaderMouseClick
        Dim index As Integer = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DataGridFriend.Rows(index)
        txtFriendship.Text = selectedRow.Cells(1).Value.ToString()
    End Sub

End Class