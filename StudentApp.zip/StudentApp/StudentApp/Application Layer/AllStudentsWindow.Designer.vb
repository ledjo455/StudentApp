﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AllStudentsWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.allStudentsDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtStudentName = New System.Windows.Forms.TextBox()
        Me.addBtn = New System.Windows.Forms.Button()
        Me.searchBtn = New System.Windows.Forms.Button()
        Me.displayBtn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        CType(Me.allStudentsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 31)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(150, 24)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Students Table"
        '
        'allStudentsDataGridView
        '
        Me.allStudentsDataGridView.AllowUserToAddRows = False
        Me.allStudentsDataGridView.AllowUserToDeleteRows = False
        Me.allStudentsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.allStudentsDataGridView.BackgroundColor = System.Drawing.Color.White
        Me.allStudentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.allStudentsDataGridView.Location = New System.Drawing.Point(36, 81)
        Me.allStudentsDataGridView.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.allStudentsDataGridView.Name = "allStudentsDataGridView"
        Me.allStudentsDataGridView.ReadOnly = True
        Me.allStudentsDataGridView.RowHeadersWidth = 51
        Me.allStudentsDataGridView.Size = New System.Drawing.Size(1119, 242)
        Me.allStudentsDataGridView.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(32, 386)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 23)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Student ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(617, 386)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(167, 23)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Search By Name"
        '
        'txtStudentName
        '
        Me.txtStudentName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentName.Location = New System.Drawing.Point(801, 384)
        Me.txtStudentName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtStudentName.Name = "txtStudentName"
        Me.txtStudentName.Size = New System.Drawing.Size(132, 30)
        Me.txtStudentName.TabIndex = 8
        '
        'addBtn
        '
        Me.addBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.addBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addBtn.ForeColor = System.Drawing.Color.White
        Me.addBtn.Location = New System.Drawing.Point(340, 369)
        Me.addBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.addBtn.Name = "addBtn"
        Me.addBtn.Size = New System.Drawing.Size(148, 52)
        Me.addBtn.TabIndex = 9
        Me.addBtn.Text = "Add Friend"
        Me.addBtn.UseVisualStyleBackColor = False
        '
        'searchBtn
        '
        Me.searchBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.searchBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.searchBtn.ForeColor = System.Drawing.Color.White
        Me.searchBtn.Location = New System.Drawing.Point(965, 374)
        Me.searchBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.searchBtn.Name = "searchBtn"
        Me.searchBtn.Size = New System.Drawing.Size(127, 52)
        Me.searchBtn.TabIndex = 10
        Me.searchBtn.Text = "Search"
        Me.searchBtn.UseVisualStyleBackColor = False
        '
        'displayBtn
        '
        Me.displayBtn.BackColor = System.Drawing.Color.MidnightBlue
        Me.displayBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.displayBtn.ForeColor = System.Drawing.Color.White
        Me.displayBtn.Location = New System.Drawing.Point(965, 443)
        Me.displayBtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.displayBtn.Name = "displayBtn"
        Me.displayBtn.Size = New System.Drawing.Size(127, 46)
        Me.displayBtn.TabIndex = 11
        Me.displayBtn.Text = "Display All"
        Me.displayBtn.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(219, 36)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(385, 17)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "(to add a friend click on the table and press the Add Button)"
        '
        'lblStudentID
        '
        Me.lblStudentID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStudentID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentID.Location = New System.Drawing.Point(175, 384)
        Me.lblStudentID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(133, 28)
        Me.lblStudentID.TabIndex = 13
        '
        'AllStudentsWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.blur
        Me.ClientSize = New System.Drawing.Size(1193, 540)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.displayBtn)
        Me.Controls.Add(Me.searchBtn)
        Me.Controls.Add(Me.addBtn)
        Me.Controls.Add(Me.txtStudentName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.allStudentsDataGridView)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "AllStudentsWindow"
        Me.Text = "All Students"
        CType(Me.allStudentsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents allStudentsDataGridView As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtStudentName As TextBox
    Friend WithEvents addBtn As Button
    Friend WithEvents searchBtn As Button
    Friend WithEvents displayBtn As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents lblStudentID As Label
End Class
