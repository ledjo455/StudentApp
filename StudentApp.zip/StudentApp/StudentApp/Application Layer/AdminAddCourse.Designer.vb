﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminAddCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim EligibilityLabel As System.Windows.Forms.Label
        Dim DepartmentLabel As System.Windows.Forms.Label
        Dim FacultyLabel As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Dim DayLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Me.UniversityMSDataSet = New StudentApp.UniversityMSDataSet()
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourseTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CourseTableAdapter()
        Me.TableAdapterManager = New StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager()
        Me.CommentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.CommentTableAdapter()
        Me.CourseBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Commentfk1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cmbEligibility = New System.Windows.Forms.ComboBox()
        Me.DepartmentComboBox = New System.Windows.Forms.ComboBox()
        Me.DepartmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Course1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FacultyComboBox = New System.Windows.Forms.ComboBox()
        Me.FacultyBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.nudCredits = New System.Windows.Forms.NumericUpDown()
        Me.DayComboBox = New System.Windows.Forms.ComboBox()
        Me.txtInstructor = New System.Windows.Forms.TextBox()
        Me.txtTime = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.DepartmentTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.DepartmentTableAdapter()
        Me.FacultyTableAdapter = New StudentApp.UniversityMSDataSetTableAdapters.FacultyTableAdapter()
        Me.txtLocation = New System.Windows.Forms.TextBox()
        EligibilityLabel = New System.Windows.Forms.Label()
        DepartmentLabel = New System.Windows.Forms.Label()
        FacultyLabel = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        DayLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Commentfk1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DepartmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Course1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FacultyBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudCredits, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'EligibilityLabel
        '
        EligibilityLabel.AutoSize = True
        EligibilityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EligibilityLabel.Location = New System.Drawing.Point(440, 264)
        EligibilityLabel.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        EligibilityLabel.Name = "EligibilityLabel"
        EligibilityLabel.Size = New System.Drawing.Size(116, 29)
        EligibilityLabel.TabIndex = 1
        EligibilityLabel.Text = "Eligibility:"
        '
        'DepartmentLabel
        '
        DepartmentLabel.AutoSize = True
        DepartmentLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DepartmentLabel.Location = New System.Drawing.Point(35, 194)
        DepartmentLabel.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        DepartmentLabel.Name = "DepartmentLabel"
        DepartmentLabel.Size = New System.Drawing.Size(144, 29)
        DepartmentLabel.TabIndex = 2
        DepartmentLabel.Text = "Department:"
        '
        'FacultyLabel
        '
        FacultyLabel.AutoSize = True
        FacultyLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FacultyLabel.Location = New System.Drawing.Point(72, 264)
        FacultyLabel.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        FacultyLabel.Name = "FacultyLabel"
        FacultyLabel.Size = New System.Drawing.Size(95, 29)
        FacultyLabel.TabIndex = 4
        FacultyLabel.Text = "Faculty:"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(454, 191)
        Label1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(96, 29)
        Label1.TabIndex = 6
        Label1.Text = "Credits:"
        '
        'DayLabel
        '
        DayLabel.AutoSize = True
        DayLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DayLabel.Location = New System.Drawing.Point(454, 56)
        DayLabel.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        DayLabel.Name = "DayLabel"
        DayLabel.Size = New System.Drawing.Size(60, 29)
        DayLabel.TabIndex = 8
        DayLabel.Text = "Day:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(56, 125)
        Label2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(117, 29)
        Label2.TabIndex = 10
        Label2.Text = "Instructor:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.Location = New System.Drawing.Point(454, 122)
        Label3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(75, 29)
        Label3.TabIndex = 12
        Label3.Text = "Time:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.Location = New System.Drawing.Point(97, 61)
        Label4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(67, 29)
        Label4.TabIndex = 14
        Label4.Text = "Title:"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label5.Location = New System.Drawing.Point(56, 334)
        Label5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(110, 29)
        Label5.TabIndex = 17
        Label5.Text = "Location:"
        '
        'UniversityMSDataSet
        '
        Me.UniversityMSDataSet.DataSetName = "UniversityMSDataSet"
        Me.UniversityMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CommentTableAdapter = Me.CommentTableAdapter
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.FriendshipTableAdapter = Nothing
        Me.TableAdapterManager.StudentCourseTableAdapter = Nothing
        Me.TableAdapterManager.StudentTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = StudentApp.UniversityMSDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CommentTableAdapter
        '
        Me.CommentTableAdapter.ClearBeforeFill = True
        '
        'CourseBindingSource1
        '
        Me.CourseBindingSource1.DataMember = "Course"
        Me.CourseBindingSource1.DataSource = Me.UniversityMSDataSet
        '
        'Commentfk1BindingSource
        '
        Me.Commentfk1BindingSource.DataMember = "Comment_fk1"
        Me.Commentfk1BindingSource.DataSource = Me.CourseBindingSource
        '
        'cmbEligibility
        '
        Me.cmbEligibility.FormattingEnabled = True
        Me.cmbEligibility.Items.AddRange(New Object() {"All", "-"})
        Me.cmbEligibility.Location = New System.Drawing.Point(557, 261)
        Me.cmbEligibility.Margin = New System.Windows.Forms.Padding(6)
        Me.cmbEligibility.Name = "cmbEligibility"
        Me.cmbEligibility.Size = New System.Drawing.Size(190, 37)
        Me.cmbEligibility.TabIndex = 2
        '
        'DepartmentComboBox
        '
        Me.DepartmentComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Department", True))
        Me.DepartmentComboBox.DataSource = Me.DepartmentBindingSource
        Me.DepartmentComboBox.DisplayMember = "Department"
        Me.DepartmentComboBox.FormattingEnabled = True
        Me.DepartmentComboBox.Location = New System.Drawing.Point(175, 191)
        Me.DepartmentComboBox.Margin = New System.Windows.Forms.Padding(6)
        Me.DepartmentComboBox.Name = "DepartmentComboBox"
        Me.DepartmentComboBox.Size = New System.Drawing.Size(196, 37)
        Me.DepartmentComboBox.TabIndex = 3
        Me.DepartmentComboBox.ValueMember = "Department"
        '
        'DepartmentBindingSource
        '
        Me.DepartmentBindingSource.DataMember = "Department"
        Me.DepartmentBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'Course1BindingSource
        '
        Me.Course1BindingSource.DataMember = "Course1"
        Me.Course1BindingSource.DataSource = Me.UniversityMSDataSet
        '
        'FacultyComboBox
        '
        Me.FacultyComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Faculty", True))
        Me.FacultyComboBox.DataSource = Me.FacultyBindingSource
        Me.FacultyComboBox.DisplayMember = "Faculty"
        Me.FacultyComboBox.FormattingEnabled = True
        Me.FacultyComboBox.Location = New System.Drawing.Point(175, 261)
        Me.FacultyComboBox.Margin = New System.Windows.Forms.Padding(6)
        Me.FacultyComboBox.Name = "FacultyComboBox"
        Me.FacultyComboBox.Size = New System.Drawing.Size(196, 37)
        Me.FacultyComboBox.TabIndex = 5
        Me.FacultyComboBox.ValueMember = "Faculty"
        '
        'FacultyBindingSource
        '
        Me.FacultyBindingSource.DataMember = "Faculty"
        Me.FacultyBindingSource.DataSource = Me.UniversityMSDataSet
        '
        'nudCredits
        '
        Me.nudCredits.Location = New System.Drawing.Point(557, 186)
        Me.nudCredits.Margin = New System.Windows.Forms.Padding(6)
        Me.nudCredits.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.nudCredits.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudCredits.Name = "nudCredits"
        Me.nudCredits.Size = New System.Drawing.Size(190, 34)
        Me.nudCredits.TabIndex = 7
        Me.nudCredits.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'DayComboBox
        '
        Me.DayComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CourseBindingSource, "Day", True))
        Me.DayComboBox.FormattingEnabled = True
        Me.DayComboBox.Items.AddRange(New Object() {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"})
        Me.DayComboBox.Location = New System.Drawing.Point(557, 56)
        Me.DayComboBox.Margin = New System.Windows.Forms.Padding(6)
        Me.DayComboBox.Name = "DayComboBox"
        Me.DayComboBox.Size = New System.Drawing.Size(190, 37)
        Me.DayComboBox.TabIndex = 9
        '
        'txtInstructor
        '
        Me.txtInstructor.Location = New System.Drawing.Point(175, 122)
        Me.txtInstructor.Margin = New System.Windows.Forms.Padding(6)
        Me.txtInstructor.Name = "txtInstructor"
        Me.txtInstructor.Size = New System.Drawing.Size(196, 34)
        Me.txtInstructor.TabIndex = 11
        '
        'txtTime
        '
        Me.txtTime.Location = New System.Drawing.Point(557, 117)
        Me.txtTime.Margin = New System.Windows.Forms.Padding(6)
        Me.txtTime.Name = "txtTime"
        Me.txtTime.Size = New System.Drawing.Size(190, 34)
        Me.txtTime.TabIndex = 13
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(175, 56)
        Me.txtTitle.Margin = New System.Windows.Forms.Padding(6)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(196, 34)
        Me.txtTitle.TabIndex = 15
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.White
        Me.btnAdd.Location = New System.Drawing.Point(627, 329)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(6)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(120, 46)
        Me.btnAdd.TabIndex = 16
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'DepartmentTableAdapter
        '
        Me.DepartmentTableAdapter.ClearBeforeFill = True
        '
        'FacultyTableAdapter
        '
        Me.FacultyTableAdapter.ClearBeforeFill = True
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(175, 329)
        Me.txtLocation.Margin = New System.Windows.Forms.Padding(6)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(196, 34)
        Me.txtLocation.TabIndex = 18
        '
        'AdminAddCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 29.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.StudentApp.My.Resources.Resources.blur1
        Me.ClientSize = New System.Drawing.Size(798, 404)
        Me.Controls.Add(Me.txtLocation)
        Me.Controls.Add(Label5)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Me.txtTime)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.txtInstructor)
        Me.Controls.Add(Label2)
        Me.Controls.Add(DayLabel)
        Me.Controls.Add(Me.DayComboBox)
        Me.Controls.Add(Me.nudCredits)
        Me.Controls.Add(Label1)
        Me.Controls.Add(FacultyLabel)
        Me.Controls.Add(Me.FacultyComboBox)
        Me.Controls.Add(DepartmentLabel)
        Me.Controls.Add(Me.DepartmentComboBox)
        Me.Controls.Add(Me.cmbEligibility)
        Me.Controls.Add(EligibilityLabel)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "AdminAddCourse"
        Me.Text = "Add Course"
        CType(Me.UniversityMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Commentfk1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DepartmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Course1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FacultyBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudCredits, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents UniversityMSDataSet As UniversityMSDataSet
    Friend WithEvents CourseBindingSource As BindingSource
    Friend WithEvents CourseTableAdapter As UniversityMSDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents TableAdapterManager As UniversityMSDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CommentTableAdapter As UniversityMSDataSetTableAdapters.CommentTableAdapter
    Friend WithEvents Commentfk1BindingSource As BindingSource
    Friend WithEvents CourseBindingSource1 As BindingSource
    Friend WithEvents cmbEligibility As ComboBox
    Friend WithEvents DepartmentComboBox As ComboBox
    Friend WithEvents FacultyComboBox As ComboBox
    Friend WithEvents nudCredits As NumericUpDown
    Friend WithEvents DayComboBox As ComboBox
    Friend WithEvents txtInstructor As TextBox
    Friend WithEvents txtTime As TextBox
    Friend WithEvents txtTitle As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents Course1BindingSource As BindingSource
    'Friend WithEvents Course1TableAdapter As UniversityMSDataSetTableAdapters.Course1TableAdapter
    Friend WithEvents DepartmentBindingSource As BindingSource
    Friend WithEvents DepartmentTableAdapter As UniversityMSDataSetTableAdapters.DepartmentTableAdapter
    Friend WithEvents FacultyBindingSource As BindingSource
    Friend WithEvents FacultyTableAdapter As UniversityMSDataSetTableAdapters.FacultyTableAdapter
    Friend WithEvents txtLocation As TextBox
End Class
